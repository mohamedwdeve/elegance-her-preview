// =====================================================
// i18n.js — Bilingual System: Arabic / English
// ÉLÉGANCE HER Store
// =====================================================

const translations = {
  ar: {
    // --- Meta & Brand ---
    pageTitle: 'الكتالوج التجاري للمنتجات الفاخرة | أناقة هير',
    brandTagline: 'حلول تجارية متكاملة • أناقة هير',

    // --- Announcement Bar ---
    announcementText: '🚫 شحن مجاني للطلبات فوق 300 ريال لجميع مناطق المملكة',
    couponCode: 'كود: ELEGANCE10',

    // --- Header ---
    searchPlaceholder: 'ابحث عن منتج، صنف، أو علامة تجارية...',
    searchMobilePlaceholder: 'ابحث في الكتالوج...',
    loginBtn: 'تسجيل الدخول',
    adminPanel: 'لوحة الإدارة ⚙️',
    adminDashboardLink: 'لوحة التحكم',
    myOrders: 'طلباتي',
    logout: 'تسجيل الخروج',
    themeToggleTitle: 'تبديل المظهر (فاتح / داكن)',
    cartTitleHeader: 'السلة',
    wishlistTitleHeader: 'المفضلة',

    // --- Hero Section ---
    heroBadge: 'الكتالوج التجاري لعام 2026',
    heroHeadline1: 'وجهتك الأولى',
    heroHeadlineAccent: 'للمنتجات الفاخرة التجارية',
    heroHeadline2: 'جودة موثوقة تلبي احتياجاتك التجارية',
    heroDesc: 'نوفر أفضل المنتجات بمعايير الجودة والموثوقية العالية، مع حلول مرنة تناسب احتياجاتك التجارية والمؤسسية',
    shopNow: 'تصفح الكتالوج',
    saleOffers: 'عروض مميزة 🏷️',
    trust1: 'منتجات أصلية 100%',
    trust2: 'شحن وتوصيل فائق السرعة',
    trust3: 'استبدال واسترجاع ميسر',
    floatingCard1: '+15,000 عميلة سعيدة',
    floatingCard1Sub: 'تقييم 4.9/5',
    floatingCard2: 'توصيل لجميع المدن 📦',

    // --- Features Bar ---
    feat1Title: 'شحن مجاني وسريع',
    feat1Sub: 'للطلبات فوق 300 ريال',
    feat2Title: 'جودة معتمدة ومضمونة',
    feat2Sub: 'أعلى الخامات والماركات العالمية',
    feat3Title: 'دفع آمن ومتعدد',
    feat3Sub: 'بطاقة مدى / فيزا / عند الاستلام',
    feat4Title: 'دعم تجاري 24/7',
    feat4Sub: 'دعم متواصل عبر الواتساب',

    // --- Products Section ---
    productsSectionTitle: 'الكتالوج',
    productsSectionBrand: 'المنتجات التجارية',
    productsSectionDesc: 'مجموعة مختارة بعناية من المنتجات الفاخرة لتلبية احتياجاتك التجارية',
    sortLabel: 'الترتيب:',
    sortDefault: 'الموصى بها',
    sortPriceAsc: 'السعر: من الأقل للأعلى',
    sortPriceDesc: 'السعر: من الأعلى للأقل',
    sortRating: 'الأعلى تقييماً ⭐',
    sortNewest: 'الأحدث ✨',
    discountOnly: 'العروض فقط 🏷️',
    loading: 'جاري التحميل...',
    addToCart: 'أضف للطلب',
    stockWarning: 'متبقي {n} قطع فقط!',
    noProductsTitle: 'لا توجد منتجات مطابقة',
    noProductsDesc: 'غيّر خيارات البحث أو تصفح أقساماً أخرى.',
    resetFilters: 'إعادة تعيين الفلاتر',
    serverError: 'تعذر تحميل المنتجات. تأكد من تشغيل الخادم.',
    currency: 'ر.س',
    reviews: 'تقييم',
    saved: 'توفير',
    available: 'المتوفر:',
    piece: 'قطعة',
    outOfStock: 'غير متوفر',
    inStock: 'متوفر',
    lowStock: 'كمية محدودة',

    // --- Categories ---
    cat_all: 'جميع المنتجات',
    cat_dresses: 'فساتين وأزياء',
    cat_bags: 'حقائب يد فاخرة',
    cat_beauty: 'عطور ومكياج',
    cat_jewelry: 'مجوهرات وساعات',
    cat_shoes: 'أحذية راقية',

    // --- Quick View Modal / Product Details ---
    qvSize: 'المقاس / السعة:',
    qvColor: 'اللون:',
    qvQty: 'الكمية:',
    qvAddToCart: 'إضافة للطلب',
    qvWishlist: 'المفضلة',
    defaultCategory: 'منتج نسائي',
    qvDescription: 'وصف المنتج وتفاصيله الفاخرة:',
    exclusivePiece: 'منتج تجاري فاخر',
    featQuickShip: 'شحن وتوصيل فائق السرعة',
    feat100Orig: 'أصلي ومضمون 100%',
    featEasyReturn: 'استبدال واسترجاع ميسر',
    qvClose: 'إغلاق',
    qvSku: 'رقم المنتج / SKU:',
    qvSpecs: 'المواصفات الفنية:',
    qvMaterial: 'الخامة والمادة:',
    qvOrigin: 'بلد المنشأ:',
    qvWarranty: 'الضمان:',
    qvDimensions: 'القياسات / التفاصيل:',
    qvInquire: 'استفسار / طلب عرض سعر',
    availability: 'التوفر:',

    // --- Promo Banner ---
    promoBadge: 'عرض نهاية الأسبوع',
    promoTitle: 'خصم إضافي 20% على العطور والأزياء الساهرة!',
    promoDesc: 'استخدمي كود الخصم الحصري عند إتمام الطلب واحصلي على تخفيض فوري إضافي لجميع مشترياتك.',
    promoCodeLabel: 'كود الخصم:',
    copyCode: 'نسخ الكود 📋',
    codeCopied: 'تم نسخ الكود ELEGANCE20 بنجاح!',

    // --- Testimonials ---
    testimonialsTitle: 'ماذا تقول عميلاتنا؟ 💖',
    testimonialsDesc: 'نعتز بثقة أكثر من 15,000 عميلة من مختلف مدن المملكة',
    t1Text: '"طلبت فستان السهرة الزمردي والتوصيل وصلني في الرياض خلال يومين فقط! الخامة حرير طبيعي فاخر والتفصيل مضبوط تماماً كما في الصور."',
    t1Name: 'نوف الشمري',
    t1Verified: 'مشترية مؤكدة ✓',
    t2Text: '"عطر رويال عود & روز ثباته خيالي! ريحته فخمة جداً وكل من قابلته سألني عنه. التغليف كان أنيق وراقي جداً كأنه هدية."',
    t2Name: 'عبير القحطاني',
    t2Verified: 'مشترية مؤكدة ✓',
    t3Text: '"الحقيبة الجلدية الكلاسيكية جودتها لا تقل عن الماركات العالمية بسعر معقول جداً. خدمة العملاء قمة في الذوق والرقي."',
    t3Name: 'لمى السبيعي',
    t3Verified: 'مشترية مؤكدة ✓',

    // --- Footer ---
    footerAbout: 'وجهتك التجارية الأولى للمنتجات الفاخرة عالية الجودة في المملكة والخليج.',
    footerShopTitle: 'أقسام المتجر',
    footerDresses: 'فساتين وأزياء راقية',
    footerBags: 'حقائب يد فاخرة',
    footerBeauty: 'عطور ومستحضرات تجميل',
    footerJewelry: 'مجوهرات وساعات',
    footerShoes: 'أحذية نسائية',
    footerCareTitle: 'خدمة العميلات',
    footerShipping: 'سياسة الشحن والتوصيل',
    footerReturns: 'سياسة الاستبدال والاسترجاع',
    footerSizeGuide: 'دليل المقاسات النسائية',
    footerFaq: 'الأسئلة الشائعة',
    footerAdminLink: 'لوحة إدارة المتجر ⚙️',
    footerNewsletterTitle: 'اشتركي بالنشرة البريدية',
    footerNewsletterDesc: 'احصلي على كود خصم 10% فور اشتراكك لمشترياتك القادمة.',
    footerEmailPlaceholder: 'بريدك الإلكتروني...',
    footerSubscribe: 'اشتراك',
    footerWhatsapp: 'واتساب المبيعات: +966 50 123 4567',
    footerCopyright: '© 2026 متجر أناقة هير (ÉLÉGANCE HER). جميع الحقوق محفوظة.',
    footerPayment: 'دفع آمن عبر:',

    // --- Cart ---
    cartTitle: 'سلة التسوق الخاصة بكِ',
    cartEmpty: 'سلتك فارغة حالياً',
    cartEmptyDesc: 'استكشفي أحدث القطع وأضيفي ما يعجبك لسلتك.',
    startShopping: 'ابدئي التسوق الآن',
    couponPlaceholder: 'كود الخصم (مثال: ELEGANCE10)',
    applyCoupon: 'تطبيق',
    subtotal: 'المجموع الفرعي:',
    discount: 'الخصم المطبق:',
    shipping: 'الشحن والتوصيل:',
    total: 'المجموع الكلي:',
    freeShipping: 'مجاني 🎁',
    checkout: 'متابعة إتمام الطلب',
    sizeLabel: 'المقاس:',
    colorLabel: 'اللون:',
    couponInvalid: 'كود الخصم غير صالح. جربي: ELEGANCE10',
    coupon10: 'تم تطبيق كود خصم 10% بنجاح! 🎉',
    coupon20: 'تم تطبيق كود خصم 20% الحصري! ✨',
    cartItemRemoved: 'تم حذف المنتج من السلة',

    // --- Wishlist ---
    wishlistTitle: 'قائمة أمنياتك والمفضلة',
    wishlistEmpty: 'قائمة المفضلة فارغة',
    wishlistEmptyDesc: 'انقري على علامة القلب على أي منتج لحفظه هنا.',
    moveToCart: 'نقل إلى السلة 🛍️',
    wishlistAdded: 'تمت إضافة المنتج إلى قائمة المفضلة ❤️',
    wishlistRemoved: 'تمت إزالة المنتج من قائمة المفضلة',
    cartAdded: 'تمت إضافة "{name}" إلى السلة بنجاح!',
    cartEmpty2: 'السلة فارغة! أضيفي منتجات أولاً',

    // --- Checkout ---
    checkoutTitle: 'إتمام الشراء والطلب 🛍️',
    checkoutDesc: 'يرجى تعبئة بيانات التوصيل بدقة لتأكيد إرسال الشحنة إليكِ',
    fullName: 'الاسم الكامل *',
    namePlaceholder: 'مثال: سارة محمد',
    phone: 'رقم الهاتف / واتساب *',
    phonePlaceholder: '05xxxxxxxx',
    email: 'البريد الإلكتروني (اختياري)',
    city: 'المدينة *',
    cityPlaceholder: 'مثال: الرياض، جدة، الدمام...',
    address: 'العنوان التفصيلي / الحي *',
    addressPlaceholder: 'الحي، اسم الشارع، رقم المبنى',
    paymentMethod: 'طريقة الدفع المفضلة:',
    cod: 'الدفع عند الاستلام',
    codDesc: 'ادفعي نقداً عند وصول الشحنة',
    card: 'بطاقة مدى / فيزا',
    cardDesc: 'دفع إلكتروني فوري وآمن',
    totalDue: 'المبلغ الإجمالي المستحق:',
    confirmOrder: 'تأكيد وإتمام الطلب',
    processingOrder: 'جاري تأكيد طلبك...',
    serverConnectError: 'تعذر الاتصال بالخادم، يرجى المحاولة لاحقاً',
    orderError: 'حدث خطأ أثناء حفظ الطلب',

    // --- Auth / Login ---
    loginTitle: 'الدخول إلى النظام',
    loginDesc: 'سجل دخولك لإدارة الكتالوج والطلبات وصلاحياتك',
    loginWithGoogle: 'تسجيل الدخول عبر جوجل:',
    googleBtn: 'تسجيل الدخول بحساب Google',
    orTestRoles: 'أو تجربة نظام الصلاحيات مباشرة',
    adminRoleTitle: 'دخول كمديرة النظام (Admin)',
    adminRoleBadge: 'صلاحية كاملة',
    adminRoleDesc: 'إضافة وتعديل وحذف المنتجات، الاطلاع على تقارير المبيعات، وتغيير حالات الطلبات وإدارة المستخدمين.',
    customerRoleTitle: 'دخول كعميلة (Customer)',
    customerRoleBadge: 'عميل',
    customerRoleDesc: 'تصفح المنتجات والشراء وتتبع الطلبات الخاصة (مع حظر الوصول للوحة الإدارة).',
    adminRoleLabel: 'مديرة النظام 👑',
    customerRoleLabel: 'عميلة المتجر 🛍️',
    rolePrefix: 'الرتبة:',

    // --- My Orders ---
    myOrdersTitle: 'سجل طلباتي ومشترياتي',
    myOrdersDesc: 'تابعي حالة شحناتك وتفاصيل المشتريات السابقة',
    myOrdersLoading: 'جاري تحميل طلباتكِ...',
    loginFirst: 'يرجى تسجيل الدخول أولاً لعرض طلباتكِ',
    noOrders: 'لا توجد طلبات سابقة حتى الآن',
    noOrdersDesc: 'كل طلب تقومين به سيظهر هنا لتتبعه أولاً بأول.',
    orderNum: 'طلب #',
    deliverTo: 'التوصيل إلى:',
    paymentLabel: 'طريقة الدفع:',
    codLabel: 'الدفع عند الاستلام',
    cardLabel: 'بطاقة مدى / فيزا',
    items: 'منتجات',
    fetchOrdersError: 'تعذر جلب الطلبات',

    // --- Toast / General ---
    logoutSuccess: 'تم تسجيل الخروج بنجاح 👋',
    continueShopping: 'متابعة التسوق 🛍️',
    continueBtn: 'رائع، استمرار',
    welcomeBack: 'مرحباً بكِ',
    welcomeMsg: 'تم تسجيل الدخول بنجاح بحساب Google (الرتبة: {role})',
    adminWelcome: 'مديرة النظام',
    customerWelcome: 'عميلة',
    demoLoginError: 'تعذر تسجيل الدخول التجريبي',
    googleAuthError: 'حدث خطأ أثناء معالجة تسجيل الدخول',
    googleLoginFailed: 'فشل تسجيل الدخول بحساب جوجل',
    googleLoginPromptTitle: 'تسجيل الدخول الذكي عبر Google 🌐',
    googleLoginPromptText: 'أدخلي اسمكِ أو بريدكِ الإلكتروني لتسجيل الدخول الفوري ومحاكاة حساب Google الحقيقي:',
    googleLoginInputDefault: 'سارة - sarah.fashion@gmail.com',
    googleLoginConfirm: 'متابعة الدخول',
    googleLoginCancel: 'إلغاء',
    googleLoginRequired: 'يرجى إدخال بريدكِ أو اسمكِ للمتابعة',
    orderSuccess: 'تهانينا! تم استلام طلبك بنجاح 🌸',
    orderNumLabel: 'رقم الطلب: #',
    orderThankYou: 'شكراً لكِ',
    orderThankYouFor: 'لاختيارها أناقة هير.',
    orderShipMsg: 'سنقوم بتجهيز وشحن طلبك إلى',
    orderShipSoon: 'في أقرب وقت.',
    orderTotalLabel: 'المبلغ الإجمالي:',
    paymentCod: 'الدفع عند الاستلام',
    paymentCard: 'بطاقة مدى / فيزا',
    demoAdminDesc: 'تم الدخول كـ (مديرة النظام) - لديكِ كافة صلاحيات الإدارة وإضافة وتعديل المنتجات والإحصائيات!',
    demoCustomerDesc: 'تم الدخول كـ (عميلة المتجر) - يمكنكِ الشراء، إدارة السلة، وتتبع طلباتكِ الخاصة.',
    langBtn: 'EN',
    langTitle: 'Switch to English',
    dir: 'rtl',
    lang: 'ar',
  },

  en: {
    // --- Meta & Brand ---
    pageTitle: 'Corporate Product Catalog | ÉLÉGANCE HER',
    brandTagline: 'Product Catalog • Corporate Business Solutions',

    // --- Announcement Bar ---
    announcementText: '🏢 Free shipping on bulk & corporate orders — Contact us for exclusive pricing',
    couponCode: 'Code: ELEGANCE10',

    // --- Header ---
    searchPlaceholder: 'Search dresses, bags, perfumes, jewelry...',
    searchMobilePlaceholder: 'Search our products...',
    loginBtn: 'Sign In',
    adminPanel: 'Admin Panel ⚙️',
    adminDashboardLink: 'Admin Dashboard',
    myOrders: 'My Orders',
    logout: 'Sign Out',
    themeToggleTitle: 'Toggle Theme (Day / Night)',
    cartTitleHeader: 'Cart',
    wishlistTitleHeader: 'Wishlist',

    // --- Hero Section ---
    heroBadge: 'Corporate Product Catalog 2026',
    heroHeadline1: 'Your Premier Destination',
    heroHeadlineAccent: 'for Premium Corporate Products',
    heroHeadline2: 'Trusted Quality for All Your Business Needs',
    heroDesc: 'We provide the finest products to the highest standards of quality and reliability, with flexible solutions tailored for your business and enterprise needs',
    shopNow: 'Browse Catalog',
    saleOffers: 'Special Offers 🏷️',
    trust1: '100% Authentic Products',
    trust2: 'Fast & Reliable Shipping',
    trust3: 'Easy Exchange & Returns',
    floatingCard1: '+15,000 Happy Customers',
    floatingCard1Sub: '⭐⭐⭐⭐⭐ Rated 4.9/5',
    floatingCard2: 'Delivery to All Cities 📦',

    // --- Features Bar ---
    feat1Title: 'Free Express Shipping',
    feat1Sub: 'On orders over 300 SAR',
    feat2Title: 'Certified Quality Guaranteed',
    feat2Sub: 'Premium fabrics & brands',
    feat3Title: 'Safe & Multiple Payments',
    feat3Sub: 'Mada, Visa & Cash on Delivery',
    feat4Title: '24/7 Business Support',
    feat4Sub: 'Continuous support via WhatsApp',

    // --- Products Section ---
    productsSectionTitle: 'Browse the',
    productsSectionBrand: 'Corporate Catalog',
    productsSectionDesc: 'Discover a curated range of products carefully selected for your business needs',
    sortLabel: 'Sort:',
    sortDefault: 'Default (Recommended)',
    sortPriceAsc: 'Price: Low to High',
    sortPriceDesc: 'Price: High to Low',
    sortRating: 'Top Rated ⭐',
    sortNewest: 'Newest Products ✨',
    discountOnly: 'Sale Items Only 🏷️',
    loading: 'Loading...',
    addToCart: 'Add to Order',
    stockWarning: 'Only {n} left in stock!',
    noProductsTitle: 'No products found!',
    noProductsDesc: 'Try changing your search or browse other categories to discover our amazing collection.',
    resetFilters: 'Reset Filters',
    serverError: 'Could not load products from the server. Please make sure the server is running.',
    currency: 'SAR',
    reviews: 'reviews',
    saved: 'You save',
    available: 'Available:',
    piece: 'pcs',
    outOfStock: 'Out of Stock',
    inStock: 'In Stock',
    lowStock: 'Low Stock',

    // --- Categories ---
    cat_all: 'All Products',
    cat_dresses: 'Dresses & Fashion',
    cat_bags: 'Luxury Handbags',
    cat_beauty: 'Perfumes & Beauty',
    cat_jewelry: 'Jewelry & Watches',
    cat_shoes: 'Luxury Shoes',

    // --- Quick View Modal / Product Details ---
    qvSize: 'Size / Capacity:',
    qvColor: 'Color:',
    qvQty: 'Quantity:',
    qvAddToCart: 'Add to Order',
    qvWishlist: 'Wishlist',
    defaultCategory: "Women's Product",
    qvDescription: 'Product Description & Highlights:',
    exclusivePiece: 'Premium Corporate Product',
    featQuickShip: 'Fast Express Delivery',
    feat100Orig: '100% Authentic Quality',
    featEasyReturn: 'Easy Returns & Exchange',
    qvClose: 'Close',
    qvSku: 'Product SKU:',
    qvSpecs: 'Technical Specifications:',
    qvMaterial: 'Material:',
    qvOrigin: 'Country of Origin:',
    qvWarranty: 'Warranty:',
    qvDimensions: 'Dimensions:',
    qvInquire: 'Inquire / Request Quote',
    availability: 'Availability:',

    // --- Promo Banner ---
    promoBadge: 'Weekend Offer',
    promoTitle: 'Extra 20% Off on Perfumes & Evening Wear!',
    promoDesc: 'Use the exclusive discount code at checkout and get an instant additional discount on all your purchases.',
    promoCodeLabel: 'Discount Code:',
    copyCode: 'Copy Code 📋',
    codeCopied: 'Code ELEGANCE20 copied successfully!',

    // --- Testimonials ---
    testimonialsTitle: 'What Our Customers Say 💖',
    testimonialsDesc: 'Trusted by over 15,000 customers from across the Kingdom',
    t1Text: '"I ordered the emerald evening gown and it arrived in Riyadh in just two days! The fabric is genuine luxury silk and the tailoring is exactly as shown in the photos."',
    t1Name: 'Nouf Al-Shammari',
    t1Verified: 'Verified Buyer ✓',
    t2Text: '"Royal Oud & Rose perfume has incredible longevity! It\'s so luxurious and everyone I met asked me about it. The packaging was elegant and classy, like a gift."',
    t2Name: 'Abeer Al-Qahtani',
    t2Verified: 'Verified Buyer ✓',
    t3Text: '"The classic leather bag quality rivals international brands at a very reasonable price. Customer service was absolutely top-notch."',
    t3Name: 'Lama Al-Subaie',
    t3Verified: 'Verified Buyer ✓',

    // --- Footer ---
    footerAbout: 'Your premier corporate destination for luxury high-quality products in Saudi Arabia and the Gulf.',
    footerShopTitle: 'Store Sections',
    footerDresses: 'Dresses & Fashion',
    footerBags: 'Luxury Handbags',
    footerBeauty: 'Perfumes & Beauty',
    footerJewelry: 'Jewelry & Watches',
    footerShoes: "Women's Shoes",
    footerCareTitle: 'Customer Care',
    footerShipping: 'Shipping & Delivery Policy',
    footerReturns: 'Exchange & Return Policy',
    footerSizeGuide: "Women's Size Guide",
    footerFaq: 'Frequently Asked Questions',
    footerAdminLink: 'Store Admin Panel ⚙️',
    footerNewsletterTitle: 'Subscribe to Newsletter',
    footerNewsletterDesc: 'Get a 10% discount code instantly upon subscribing for your next purchase.',
    footerEmailPlaceholder: 'Your email...',
    footerSubscribe: 'Subscribe',
    footerWhatsapp: 'Sales WhatsApp: +966 50 123 4567',
    footerCopyright: '© 2026 ÉLÉGANCE HER Store. All Rights Reserved.',
    footerPayment: 'Secure payment via:',

    // --- Cart ---
    cartTitle: 'Your Shopping Cart',
    cartEmpty: 'Your cart is currently empty',
    cartEmptyDesc: 'Explore our latest pieces and add what you love to your cart.',
    startShopping: 'Start Shopping Now',
    couponPlaceholder: 'Discount code (e.g. ELEGANCE10)',
    applyCoupon: 'Apply',
    subtotal: 'Subtotal:',
    discount: 'Discount Applied:',
    shipping: 'Shipping & Delivery:',
    total: 'Total:',
    freeShipping: 'Free 🎁',
    checkout: 'Proceed to Checkout',
    sizeLabel: 'Size:',
    colorLabel: 'Color:',
    couponInvalid: 'Invalid coupon code. Try: ELEGANCE10',
    coupon10: '10% discount applied successfully! 🎉',
    coupon20: '20% exclusive discount applied! ✨',
    cartItemRemoved: 'Item removed from cart',

    // --- Wishlist ---
    wishlistTitle: 'Your Wishlist',
    wishlistEmpty: 'Wishlist is empty',
    wishlistEmptyDesc: 'Tap the heart icon on any product to save it here.',
    moveToCart: 'Move to Cart 🛍️',
    wishlistAdded: 'Product added to wishlist ❤️',
    wishlistRemoved: 'Product removed from wishlist',
    cartAdded: '"{name}" added to cart successfully!',
    cartEmpty2: 'Cart is empty! Add products first',

    // --- Checkout ---
    checkoutTitle: 'Complete Your Order 🛍️',
    checkoutDesc: 'Please fill in your delivery details accurately to confirm your shipment',
    fullName: 'Full Name *',
    namePlaceholder: 'e.g. Sarah Mohammed',
    phone: 'Phone / WhatsApp *',
    phonePlaceholder: '05xxxxxxxx',
    email: 'Email (Optional)',
    city: 'City *',
    cityPlaceholder: 'e.g. Riyadh, Jeddah, Dammam...',
    address: 'Detailed Address / District *',
    addressPlaceholder: 'District, Street Name, Building Number',
    paymentMethod: 'Preferred Payment Method:',
    cod: 'Cash on Delivery',
    codDesc: 'Pay cash when your order arrives',
    card: 'Mada / Visa Card',
    cardDesc: 'Instant secure electronic payment',
    totalDue: 'Total Amount Due:',
    confirmOrder: 'Confirm & Place Order',
    processingOrder: 'Processing your order...',
    serverConnectError: 'Could not connect to server, please try again later',
    orderError: 'An error occurred while saving the order',

    // --- Auth / Login ---
    loginTitle: 'System Login',
    loginDesc: 'Sign in to manage the catalog, orders, and your permissions',
    loginWithGoogle: 'Sign in with Google:',
    googleBtn: 'Sign in with Google Account',
    orTestRoles: 'Or test the roles system directly',
    adminRoleTitle: 'Enter as System Admin',
    adminRoleBadge: 'Full Access',
    adminRoleDesc: 'Add, edit, and delete products, view sales reports, change order statuses and manage users.',
    customerRoleTitle: 'Enter as Customer',
    customerRoleBadge: 'Customer',
    customerRoleDesc: 'Browse products, purchase, and track personal orders (admin panel access is blocked).',
    adminRoleLabel: 'System Admin 👑',
    customerRoleLabel: 'Store Customer 🛍️',
    rolePrefix: 'Role:',

    // --- My Orders ---
    myOrdersTitle: 'My Orders History',
    myOrdersDesc: 'Track your shipments and view previous purchase details',
    myOrdersLoading: 'Loading your orders...',
    loginFirst: 'Please sign in first to view your orders',
    noOrders: 'No previous orders yet',
    noOrdersDesc: 'Every order you place will appear here for you to track.',
    orderNum: 'Order #',
    deliverTo: 'Delivery to:',
    paymentLabel: 'Payment Method:',
    codLabel: 'Cash on Delivery',
    cardLabel: 'Mada / Visa Card',
    items: 'items',
    fetchOrdersError: 'Failed to load orders',

    // --- Toast / General ---
    logoutSuccess: 'Signed out successfully 👋',
    continueShopping: 'Continue Shopping 🛍️',
    continueBtn: 'Great, Continue',
    welcomeBack: 'Welcome back',
    welcomeMsg: 'Successfully signed in with Google (Role: {role})',
    adminWelcome: 'System Admin',
    customerWelcome: 'Customer',
    demoLoginError: 'Demo login failed',
    googleAuthError: 'An error occurred while processing sign-in',
    googleLoginFailed: 'Google account sign-in failed',
    googleLoginPromptTitle: 'Smart Google Sign-In 🌐',
    googleLoginPromptText: 'Enter your name or email to sign in instantly and simulate a real Google account:',
    googleLoginInputDefault: 'Sarah - sarah.fashion@gmail.com',
    googleLoginConfirm: 'Continue Sign-In',
    googleLoginCancel: 'Cancel',
    googleLoginRequired: 'Please enter your email or name to continue',
    orderSuccess: 'Congratulations! Your order has been received 🌸',
    orderNumLabel: 'Order #: ',
    orderThankYou: 'Thank you',
    orderThankYouFor: 'for choosing ÉLÉGANCE HER.',
    orderShipMsg: 'We will prepare and ship your order to',
    orderShipSoon: 'as soon as possible.',
    orderTotalLabel: 'Total Amount:',
    paymentCod: 'Cash on Delivery',
    paymentCard: 'Mada / Visa Card',
    demoAdminDesc: 'Logged in as (System Admin) - You have full admin privileges including products, stats & orders management!',
    demoCustomerDesc: 'Logged in as (Store Customer) - You can shop, manage cart, and track your personal orders.',
    langBtn: 'AR',
    langTitle: 'التبديل إلى العربية',
    dir: 'ltr',
    lang: 'en',
  }
};

// =====================================================
// Common Translation Dictionaries (Options, Badges)
// =====================================================
const optionTranslations = {
  // Sizes
  'مقاس واحد': { ar: 'مقاس واحد', en: 'One Size' },
  '100 مل': { ar: '100 مل', en: '100 ml' },
  'قياسي': { ar: 'قياسي', en: 'Standard' },
  'S': { ar: 'S', en: 'S' },
  'M': { ar: 'M', en: 'M' },
  'L': { ar: 'L', en: 'L' },
  'XL': { ar: 'XL', en: 'XL' },
  '37': { ar: '37', en: '37' },
  '38': { ar: '38', en: '38' },
  '39': { ar: '39', en: '39' },
  '40': { ar: '40', en: '40' },
  '52': { ar: '52', en: '52' },
  '54': { ar: '54', en: '54' },
  '56': { ar: '56', en: '56' },

  // Colors
  'أخضر زمردي': { ar: 'أخضر زمردي', en: 'Emerald Green' },
  'أسود ملكي': { ar: 'أسود ملكي', en: 'Royal Black' },
  'كحلي': { ar: 'كحلي', en: 'Navy Blue' },
  'بيج كريمي': { ar: 'بيج كريمي', en: 'Cream Beige' },
  'أسود ناصع': { ar: 'أسود ناصع', en: 'Jet Black' },
  'بني كراميل': { ar: 'بني كراميل', en: 'Caramel Brown' },
  'وردي ذهبي': { ar: 'وردي ذهبي', en: 'Rose Gold' },
  'ذهبي لامع': { ar: 'ذهبي لامع', en: 'Glossy Gold' },
  'فضي استرليني': { ar: 'فضي استرليني', en: 'Sterling Silver' },
  'عنابي فاخر': { ar: 'عنابي فاخر', en: 'Burgundy' },
  'بيج نيود': { ar: 'بيج نيود', en: 'Nude Beige' },
  'أسود': { ar: 'أسود', en: 'Black' },
  'أبيض عاجي': { ar: 'أبيض عاجي', en: 'Ivory White' },
  'فضي': { ar: 'فضي', en: 'Silver' },
  'وردي هادئ': { ar: 'وردي هادئ', en: 'Soft Pink' },
  'مشمشي': { ar: 'مشمشي', en: 'Peach' },
  'زهري': { ar: 'زهري', en: 'Pink' },
  'عسلي': { ar: 'عسلي', en: 'Honey Tan' },

  // Badges
  'الأكثر مبيعاً': { ar: 'الأكثر مبيعاً', en: 'Best Seller' },
  'جديد': { ar: 'جديد', en: 'New' },
  'حصري': { ar: 'حصري', en: 'Exclusive' },
  'عرض خاص': { ar: 'عرض خاص', en: 'Special Offer' },
};

function translateOption(value) {
  if (!value) return '';
  const item = optionTranslations[value.trim()];
  if (item) {
    return item[currentLang] || value;
  }
  return value;
}

function translateBadge(badge) {
  if (!badge) return '';
  if (badge.includes('خصم')) {
    return currentLang === 'en' ? badge.replace('خصم', 'OFF') : badge;
  }
  const item = optionTranslations[badge.trim()];
  return item ? (item[currentLang] || badge) : badge;
}

// =====================================================
// Language State Management
// =====================================================
let currentLang = localStorage.getItem('elegance_lang') || 'ar';

function t(key, vars = {}) {
  let str = (translations[currentLang] && translations[currentLang][key]) 
    || (translations['ar'] && translations['ar'][key]) 
    || key;
  // Replace {varName} placeholders
  Object.entries(vars).forEach(([k, v]) => {
    str = str.replace(`{${k}}`, v);
  });
  return str;
}

function getLang() {
  return currentLang;
}

function setLang(lang) {
  if (!translations[lang]) return;
  currentLang = lang;
  localStorage.setItem('elegance_lang', lang);
  applyLang();
}

function toggleLang() {
  setLang(currentLang === 'ar' ? 'en' : 'ar');
}

// Apply language to static and dynamic DOM elements
function applyLang() {
  const html = document.documentElement;
  const tr = translations[currentLang];

  html.setAttribute('lang', tr.lang);
  html.setAttribute('dir', tr.dir);
  document.title = tr.pageTitle;

  // Update all [data-i18n] elements
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (key && tr[key] !== undefined) {
      if (el.getAttribute('data-i18n-html') === 'true') {
        el.innerHTML = tr[key];
      } else {
        el.textContent = tr[key];
      }
    }
  });

  // Update placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (key && tr[key] !== undefined) {
      el.placeholder = tr[key];
    }
  });

  // Update title attributes
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    if (key && tr[key] !== undefined) {
      el.title = tr[key];
    }
  });

  // Lang toggle button
  const langBtn = document.getElementById('langToggleBtn');
  const langBtnText = document.getElementById('langBtnText');
  if (langBtnText) {
    langBtnText.textContent = tr.langBtn;
  } else if (langBtn) {
    langBtn.textContent = tr.langBtn;
  }
  if (langBtn) {
    langBtn.title = tr.langTitle;
  }

  // Update user profile role badge if logged in
  if (typeof state !== 'undefined' && state.user) {
    const roleBadge = document.getElementById('navUserRoleBadge');
    if (roleBadge) {
      roleBadge.textContent = state.user.role === 'admin' ? tr.adminRoleLabel : tr.customerRoleLabel;
    }
    const menuUserRole = document.getElementById('menuUserRole');
    if (menuUserRole) {
      menuUserRole.textContent = `${tr.rolePrefix} ${state.user.role === 'admin' ? tr.adminRoleLabel : tr.customerRoleLabel}`;
    }
  }

  // Re-render dynamic content that depends on language
  if (typeof renderCategories === 'function') renderCategories();
  if (typeof renderProductsGrid === 'function' && window._lastProducts) renderProductsGrid(window._lastProducts);
  if (typeof updateCartBadge === 'function') updateCartBadge();
  if (typeof renderCartItems === 'function' && !document.getElementById('cartDrawer')?.classList.contains('hidden')) {
    renderCartItems();
  }

  // Re-render Quick View Modal if open
  if (typeof state !== 'undefined' && state.activeProduct) {
    const qvModal = document.getElementById('quickViewModal');
    if (qvModal && !qvModal.classList.contains('hidden') && typeof openQuickView === 'function') {
      openQuickView(state.activeProduct.id);
    }
  }

  // Brand identity comes from site settings and must survive language changes.
  if (typeof applyBrandSettings === 'function' && typeof state !== 'undefined' && state.siteSettings) {
    applyBrandSettings(state.siteSettings);
  }
}

// Immediate execution to prevent layout flickering
if (document.documentElement) {
  const initialTr = translations[currentLang];
  if (initialTr) {
    document.documentElement.setAttribute('lang', initialTr.lang);
    document.documentElement.setAttribute('dir', initialTr.dir);
  }
}

// Apply on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  applyLang();
});

// Frontend Application Logic for Élégance Her Store
// i18n helper shortcut (loaded via i18n.js)
// t(key, vars) is globally available

// Application State
const state = {
  products: [],
  categories: [],
  currentCategory: 'all',
  searchQuery: '',
  sortBy: 'default',
  onlyDiscounted: false,
  cart: JSON.parse(localStorage.getItem('elegance_cart')) || [],
  wishlist: JSON.parse(localStorage.getItem('elegance_wishlist')) || [],
  activeProduct: null,
  appliedCoupon: localStorage.getItem('elegance_coupon') || null,
  discountPercent: localStorage.getItem('elegance_coupon') === 'ELEGANCE20' ? 20 : (localStorage.getItem('elegance_coupon') === 'ELEGANCE10' ? 10 : 0),
  currentUser: null,
  siteSettings: null,
  demoMode: false,
  googleEnabled: false,
  token: localStorage.getItem('elegance_token') || null
};

let googleAuthInitialized = false;
let googleButtonRendered = false;
let googleButtonRetryCount = 0;

// API Base URL
const API_BASE = '/api';
const IS_GITHUB_PAGES = window.location.hostname.endsWith('.github.io') || new URLSearchParams(window.location.search).get('staticPreview') === '1';
const SITE_BASE = new URL('.', window.location.href).pathname;
const STATIC_DATA_BASE = `${SITE_BASE}data/`;
let staticProductsCache = null;

function resolveSiteAsset(url) {
  if (!IS_GITHUB_PAGES || !url || /^https?:\/\//i.test(url)) return url;
  return `${SITE_BASE}${String(url).replace(/^\/+/, '')}`;
}

function disableStaticCommerceActions(root = document) {
  if (!IS_GITHUB_PAGES) return;
  root.querySelectorAll('button[onclick*="quickAddToCart"], button[onclick*="addQvToCart"], button[onclick="openCartDrawer()"]')
    .forEach(button => button.remove());
  root.querySelectorAll('form').forEach(form => form.classList.add('hidden'));
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

async function initApp() {
  // Apply saved language first
  if (typeof applyLang === 'function') applyLang();
  updateThemeIcon();
  await loadBrandSettings();
  if (IS_GITHUB_PAGES) {
    document.getElementById('announcementBar')?.classList.add('hidden');
    document.getElementById('staticPreviewNotice')?.classList.remove('hidden');
    document.getElementById('cartButton')?.classList.add('hidden');
    document.getElementById('staticSalesPromo')?.classList.add('hidden');
    document.getElementById('staticSalesContact')?.classList.add('hidden');
    document.getElementById('loginBtn')?.classList.add('hidden');
    document.getElementById('quickAdminLink')?.classList.add('hidden');
    document.getElementById('menuAdminLink')?.classList.add('hidden');
    document.querySelectorAll('a[href*="wa.me"], a[href="https://instagram.com"], a[href="https://tiktok.com"]').forEach(link => link.classList.add('hidden'));
  } else {
    await checkAuthStatus();
    initGoogleAuth();
  }
  await fetchCategories();
  await loadProducts();
  disableStaticCommerceActions();
  updateCartBadge();
  updateWishlistBadge();
  setupEventListeners();
}

// Load brand settings from admin
async function loadBrandSettings() {
  try {
    if (IS_GITHUB_PAGES) {
      const response = await fetch(`${STATIC_DATA_BASE}settings.json`, { cache: 'no-cache' });
      state.siteSettings = await response.json();
      applyBrandSettings(state.siteSettings);
      return;
    }
    const res = await fetch(`${API_BASE}/products/settings`, {
      cache: 'no-store'
    });
    const data = await res.json();

    if (data.success && data.data) {
      state.siteSettings = data.data;
      applyBrandSettings(data.data);
    }
  } catch (err) {
    console.log('Using default brand settings');
  }
}

function applyBrandSettings(settings = state.siteSettings || {}) {
  const siteName = settings.siteName?.trim() || 'أناقة هير';
  const siteTagline = settings.siteTagline?.trim() || '';
  const logoUrl = resolveSiteAsset(settings.logoUrl || '');
  const brandNameEls = ['brandName', 'footerBrandName', 'footerBrandNameCopy'];
  brandNameEls.forEach(id => {
    const element = document.getElementById(id);
    if (element) element.textContent = siteName;
  });

  const tagline = document.getElementById('brandTagline');
  if (tagline) tagline.textContent = siteTagline;
  const footerTagline = document.getElementById('footerBrandTagline');
  if (footerTagline) footerTagline.textContent = siteTagline;
  const metaDescription = document.getElementById('siteMetaDescription');
  if (metaDescription) metaDescription.content = siteTagline;

  const brandLogo = document.getElementById('brandLogo');
  const brandIcon = document.getElementById('brandIcon');
  const brandContainer = document.getElementById('brandLogoContainer');
  const footerLogo = document.getElementById('footerBrandLogo');
  const footerIcon = document.getElementById('footerBrandIcon');
  if (logoUrl) {
    if (brandLogo) { brandLogo.src = logoUrl; brandLogo.classList.remove('hidden'); }
    if (brandIcon) brandIcon.classList.add('hidden');
    if (brandContainer) brandContainer.style.background = 'transparent';
    if (footerLogo) { footerLogo.src = logoUrl; footerLogo.classList.remove('hidden'); }
    if (footerIcon) footerIcon.classList.add('hidden');
  } else {
    if (brandLogo) { brandLogo.removeAttribute('src'); brandLogo.classList.add('hidden'); }
    if (brandIcon) brandIcon.classList.remove('hidden');
    if (brandContainer) brandContainer.style.background = '';
    if (footerLogo) { footerLogo.removeAttribute('src'); footerLogo.classList.add('hidden'); }
    if (footerIcon) footerIcon.classList.remove('hidden');
  }

  const adminBrandName = document.getElementById('adminBrandName');
  if (adminBrandName) adminBrandName.textContent = siteName;
  const titleLabel = currentLang === 'en' ? 'Luxury Business Catalog' : 'الكتالوج التجاري للمنتجات الفاخرة';
  document.title = `${titleLabel} | ${siteName}`;
}

window.addEventListener('storage', event => {
  if (event.key !== 'elegance_site_settings' || !event.newValue) return;
  try {
    state.siteSettings = JSON.parse(event.newValue);
    applyBrandSettings(state.siteSettings);
  } catch (err) {
    console.warn('Could not read updated site settings');
  }
});

// Event Listeners Setup
function setupEventListeners() {
  // Search input with debounce
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        state.searchQuery = e.target.value.trim();
        loadProducts();
      }, 350);
    });
  }

  // Sort dropdown
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      state.sortBy = e.target.value;
      loadProducts();
    });
  }

  // Discount toggle filter
  const discountFilter = document.getElementById('discountFilter');
  if (discountFilter) {
    discountFilter.addEventListener('change', (e) => {
      state.onlyDiscounted = e.target.checked;
      loadProducts();
    });
  }

  // Checkout Form Submission
  const checkoutForm = document.getElementById('checkoutForm');
  if (checkoutForm) {
    checkoutForm.addEventListener('submit', handleCheckoutSubmit);
  }

  // Coupon Form
  const couponForm = document.getElementById('couponForm');
  if (couponForm) {
    couponForm.addEventListener('submit', handleApplyCoupon);
  }
}

// Fetch Categories from Backend
async function fetchCategories() {
  try {
    if (IS_GITHUB_PAGES) {
      const response = await fetch(`${STATIC_DATA_BASE}categories.json`, { cache: 'no-cache' });
      state.categories = await response.json();
      renderCategories();
      return;
    }
    const res = await fetch(`${API_BASE}/categories`);
    const data = await res.json();
    if (data.success) {
      state.categories = data.data;
      renderCategories();
    }
  } catch (err) {
    console.error('Error fetching categories:', err);
  }
}

// Render Category Pills
function renderCategories() {
  const container = document.getElementById('categoryTabs');
  if (!container) return;

  const isEn = getLang() === 'en';
  container.innerHTML = state.categories.map(cat => {
    const isActive = state.currentCategory === cat.id;
    const catName = isEn ? (cat.nameEn || t('cat_' + cat.id) || cat.name) : (cat.name || t('cat_' + cat.id));
    return `
      <button 
        onclick="selectCategory('${cat.id}')"
        class="category-btn flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-300 ${
          isActive 
            ? 'bg-[#252B33] text-white shadow-md shadow-gray-900/20 scale-105' 
            : 'bg-white dark:bg-[#252B33] text-gray-700 dark:text-gray-200 hover:bg-[#F4F5F6] dark:hover:bg-[#414852] border border-gray-200 dark:border-gray-700 hover:border-[#DDE1E5]'
        }"
      >
        <span>${catName}</span>
      </button>
    `;
  }).join('');
}

// Select Category
function selectCategory(catId) {
  state.currentCategory = catId;
  renderCategories();
  loadProducts();
}

// Load Products with filters
async function loadProducts() {
  const grid = document.getElementById('productsGrid');
  const countSpan = document.getElementById('productsCount');
  if (!grid) return;

  // Show loading skeleton
  grid.innerHTML = Array(6).fill(0).map(() => `
    <div class="bg-white dark:bg-[#252B33] rounded-2xl p-4 shadow-sm border border-gray-100 dark:border-gray-800 animate-pulse">
      <div class="w-full h-64 bg-gray-200 dark:bg-gray-800 rounded-xl mb-4"></div>
      <div class="h-4 bg-gray-200 dark:bg-gray-800 rounded w-1/3 mb-2"></div>
      <div class="h-5 bg-gray-200 dark:bg-gray-800 rounded w-3/4 mb-3"></div>
      <div class="h-6 bg-gray-200 dark:bg-gray-800 rounded w-1/2"></div>
    </div>
  `).join('');

  try {
    if (IS_GITHUB_PAGES) {
      if (!staticProductsCache) {
        const response = await fetch(`${STATIC_DATA_BASE}products.json`, { cache: 'no-cache' });
        if (!response.ok) throw new Error('Static catalog is unavailable');
        staticProductsCache = await response.json();
      }

      let products = [...staticProductsCache];
      if (state.currentCategory !== 'all') products = products.filter(product => product.category === state.currentCategory);
      if (state.searchQuery) {
        const query = state.searchQuery.toLowerCase();
        products = products.filter(product => [product.name, product.nameEn, product.description, product.descriptionEn, product.categoryName]
          .some(value => String(value || '').toLowerCase().includes(query)));
      }
      if (state.onlyDiscounted) products = products.filter(product => product.oldPrice && product.oldPrice > product.price);
      if (state.sortBy === 'price-asc') products.sort((a, b) => a.price - b.price);
      else if (state.sortBy === 'price-desc') products.sort((a, b) => b.price - a.price);
      else if (state.sortBy === 'rating') products.sort((a, b) => b.rating - a.rating);
      else if (state.sortBy === 'newest') products.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      state.products = products;
      window._lastProducts = products;
      if (countSpan) countSpan.textContent = `(${products.length} ${getLang() === 'en' ? 'products' : 'منتج'})`;
      renderProductsGrid(products);
      return;
    }

    const params = new URLSearchParams();
    if (state.currentCategory && state.currentCategory !== 'all') {
      params.append('category', state.currentCategory);
    }
    if (state.searchQuery) {
      params.append('search', state.searchQuery);
    }
    if (state.sortBy && state.sortBy !== 'default') {
      params.append('sort', state.sortBy);
    }
    if (state.onlyDiscounted) {
      params.append('onSale', 'true');
    }

    const res = await fetch(`${API_BASE}/products?${params.toString()}`);
    const result = await res.json();

    if (result.success) {
      state.products = result.data;
      window._lastProducts = result.data; // cache for lang re-render
      if (countSpan) {
        const isEn = getLang() === 'en';
        countSpan.textContent = `(${state.products.length} ${isEn ? 'products' : 'منتج'})`;
      }
      renderProductsGrid(state.products);
    }
  } catch (err) {
    console.error('Error fetching products:', err);
    grid.innerHTML = `
      <div class="col-span-full py-16 text-center text-red-500">
        <p class="text-lg font-medium">${t('serverError')}</p>
      </div>
    `;
  }
}

// Render Products Grid
function renderProductsGrid(products) {
  const grid = document.getElementById('productsGrid');
  if (!grid) return;

  const isEn = getLang() === 'en';

  if (products.length === 0) {
    grid.innerHTML = `
      <div class="col-span-full py-16 text-center">
        <div class="w-20 h-20 mx-auto mb-4 bg-gray-50 dark:bg-gray-950/40 rounded-full flex items-center justify-center text-gray-400">
          <i class="ph ph-magnifying-glass text-4xl"></i>
        </div>
        <h3 class="text-xl font-bold text-gray-800 dark:text-white mb-2">${t('noProductsTitle')}</h3>
        <p class="text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-6">${t('noProductsDesc')}</p>
        <button onclick="resetFilters()" class="px-6 py-2.5 bg-[#252B33] hover:bg-[#414852] text-white rounded-full font-bold shadow-md transition">
          ${t('resetFilters')}
        </button>
      </div>
    `;
    return;
  }

  grid.innerHTML = products.map(product => {
    const isWishlisted = state.wishlist.includes(product.id);
    const discountPercent = product.oldPrice 
      ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) 
      : 0;

    const productName = isEn ? (product.nameEn || product.name) : product.name;
    const productDesc = isEn ? (product.descriptionEn || product.description) : product.description;
    const categoryName = isEn ? (product.categoryNameEn || t('cat_' + product.category) || product.categoryName) : (product.categoryName || t('cat_' + product.category));
    const badgeText = product.badge ? translateBadge(product.badge) : '';

    return `
      <div class="product-card bg-white dark:bg-[#252B33] rounded-2xl overflow-hidden border border-[#DDE1E5] dark:border-[#2A2830] shadow-sm hover:shadow-xl flex flex-col justify-between group transition-all">
        <!-- Image & Badges -->
        <div class="relative overflow-hidden bg-[#F4F5F6] dark:bg-[#1F1D24] h-72">
          <img 
            src="${resolveSiteAsset(product.image)}" 
            alt="${productName}" 
            class="product-img w-full h-full object-cover object-top"
            loading="lazy"
          />

          <!-- Badges -->
          <div class="absolute top-3 right-3 flex flex-col gap-1.5 z-10">
            ${badgeText ? `
              <span class="text-xs px-3 py-1 font-bold rounded-full shadow-sm ${
                product.badge.includes('خصم') ? 'bg-red-600 text-white' : 'badge-gold'
              }">
                ${badgeText}
              </span>
            ` : ''}
            ${discountPercent > 0 && !product.badge?.includes('خصم') ? `
              <span class="text-xs px-2.5 py-1 font-bold rounded-full bg-red-600 text-white shadow-sm">
                -${discountPercent}%
              </span>
            ` : ''}
          </div>

          <!-- Quick Actions -->
          <div class="absolute top-3 left-3 flex flex-col gap-2 z-10">
            <!-- Wishlist Button -->
            <button 
              onclick="toggleWishlist(${product.id})" 
              aria-label="${t('wishlistTitleHeader')}"
              title="${t('wishlistTitleHeader')}"
              class="wishlist-btn ${isWishlisted ? 'active' : ''} w-9 h-9 rounded-full bg-white/90 dark:bg-[#252B33]/90 hover:bg-white dark:hover:bg-[#414852] text-gray-700 dark:text-gray-200 shadow-md flex items-center justify-center transition-transform hover:scale-110"
            >
              <i class="ph ${isWishlisted ? 'ph-heart-fill text-[#252B33]' : 'ph-heart'} text-lg"></i>
            </button>
            <!-- Quick View Button -->
            <button 
              onclick="openQuickView(${product.id})" 
              aria-label="${t('qvWishlist')}"
              title="${t('exclusivePiece')}"
              class="w-9 h-9 rounded-full bg-white/90 dark:bg-[#252B33]/90 hover:bg-white dark:hover:bg-[#414852] text-gray-700 dark:text-gray-200 shadow-md flex items-center justify-center transition-transform hover:scale-110"
            >
              <i class="ph ph-eye text-lg"></i>
            </button>
          </div>

          <!-- Stock Warning if low -->
          ${product.stock <= 5 ? `
            <div class="absolute bottom-2 right-2 left-2 bg-amber-500/90 text-white text-[11px] py-1 text-center rounded-lg backdrop-blur-sm font-medium">
              ${t('stockWarning', { n: product.stock })}
            </div>
          ` : ''}
        </div>

        <!-- Product Details -->
        <div class="p-5 flex-1 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between text-xs text-gray-400 dark:text-gray-400 mb-1.5">
              <span>${categoryName}</span>
              <div class="flex items-center text-amber-500 gap-1 font-semibold">
                <i class="ph-fill ph-star text-sm"></i>
                <span>${product.rating || 5.0}</span>
                <span class="text-gray-400 dark:text-gray-400">(${product.reviewsCount || 1})</span>
              </div>
            </div>

            <h3 class="font-bold text-gray-900 dark:text-white text-base mb-2 line-clamp-2 hover:text-[#252B33] cursor-pointer transition" onclick="openQuickView(${product.id})">
              ${productName}
            </h3>

            <p class="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 mb-4 leading-relaxed">
              ${productDesc}
            </p>
          </div>

          <!-- Price & Add to Cart -->
          <div>
            <div class="flex items-baseline gap-2 mb-4">
              <span class="text-xl font-extrabold text-[#252B33] dark:text-[#737A83]">
                ${product.price} <span class="text-xs font-semibold">${t('currency')}</span>
              </span>
              ${product.oldPrice ? `
                <span class="text-sm text-gray-400 dark:text-gray-500 line-through">
                  ${product.oldPrice} ${t('currency')}
                </span>
              ` : ''}
            </div>

            <button 
              onclick="quickAddToCart(${product.id})"
              class="w-full py-2.5 px-4 bg-gray-900 dark:bg-[#252B33] hover:bg-[#252B33] dark:hover:bg-[#252B33] text-white rounded-xl text-sm font-semibold transition-colors duration-300 flex items-center justify-center gap-2 shadow-sm group-hover:bg-[#252B33]"
            >
              <i class="ph ph-shopping-bag text-lg"></i>
              <span>${t('addToCart')}</span>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
  disableStaticCommerceActions(grid);
}

// Reset all filters
function resetFilters() {
  state.currentCategory = 'all';
  state.searchQuery = '';
  state.sortBy = 'default';
  state.onlyDiscounted = false;

  const searchInput = document.getElementById('searchInput');
  const sortSelect = document.getElementById('sortSelect');
  const discountFilter = document.getElementById('discountFilter');

  if (searchInput) searchInput.value = '';
  if (sortSelect) sortSelect.value = 'default';
  if (discountFilter) discountFilter.checked = false;

  renderCategories();
  loadProducts();
}

// Quick Add To Cart from Grid
function quickAddToCart(productId) {
  const product = state.products.find(p => p.id === productId);
  if (!product) return;

  const defaultSize = product.sizes && product.sizes.length ? product.sizes[0] : 'قياسي';
  const defaultColor = product.colors && product.colors.length ? product.colors[0] : 'اللون الأساسي';

  addToCart(product, 1, defaultSize, defaultColor);
}

// Add Item to Cart
function addToCart(product, quantity = 1, size = 'قياسي', color = 'اللون الأساسي') {
  if (IS_GITHUB_PAGES) {
    showToast('هذه نسخة عرض فقط ولا تستقبل طلبات.', 'info');
    return;
  }
  const existingIndex = state.cart.findIndex(
    item => item.id === product.id && item.selectedSize === size && item.selectedColor === color
  );

  if (existingIndex > -1) {
    state.cart[existingIndex].quantity += quantity;
  } else {
    state.cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: resolveSiteAsset(product.image),
      quantity: quantity,
      selectedSize: size,
      selectedColor: color,
      stock: product.stock
    });
  }

  saveCart();
  updateCartBadge();
  showToast(t('cartAdded', {name: product.name}), 'success');
}

// Save Cart to LocalStorage
function saveCart() {
  localStorage.setItem('elegance_cart', JSON.stringify(state.cart));
}

// Update Cart Count Badge
function updateCartBadge() {
  const totalItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  const badge = document.getElementById('cartBadge');
  if (badge) {
    badge.textContent = totalItems;
    badge.classList.toggle('hidden', totalItems === 0);
  }

  const headerTotal = document.getElementById('cartHeaderTotal');
  if (headerTotal) {
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    headerTotal.textContent = `${subtotal} ${t('currency')}`;
  }
}

// Toggle Wishlist
function toggleWishlist(productId) {
  const index = state.wishlist.indexOf(productId);
  if (index > -1) {
    state.wishlist.splice(index, 1);
    showToast(t('wishlistRemoved'), 'info');
  } else {
    state.wishlist.push(productId);
    showToast(t('wishlistAdded'), 'success');
  }

  localStorage.setItem('elegance_wishlist', JSON.stringify(state.wishlist));
  updateWishlistBadge();
  renderProductsGrid(state.products);
}

// Update Wishlist Badge
function updateWishlistBadge() {
  const badge = document.getElementById('wishlistBadge');
  if (badge) {
    badge.textContent = state.wishlist.length;
    badge.classList.toggle('hidden', state.wishlist.length === 0);
  }
}

// Open Quick View Modal / Product Details Display (صفحة تفاصيل عرض المنتج)
async function openQuickView(productId) {
  try {
    let product;
    if (IS_GITHUB_PAGES) {
      product = state.products.find(item => item.id === productId) || staticProductsCache?.find(item => item.id === productId);
      if (!product) return;
    } else {
      const res = await fetch(`${API_BASE}/products/${productId}`);
      const data = await res.json();
      if (!data.success) return;
      product = data.data;
    }
    state.activeProduct = product;

    const modal = document.getElementById('quickViewModal');
    const content = document.getElementById('quickViewContent');
    if (!modal || !content) return;

    const isEn = getLang() === 'en';
    const primaryName = isEn ? (product.nameEn || product.name) : product.name;
    const secondaryName = isEn ? (product.name !== primaryName ? product.name : '') : (product.nameEn || '');
    const description = isEn ? (product.descriptionEn || product.description) : (product.description || product.descriptionEn || '');
    const categoryName = isEn ? (product.categoryNameEn || t('cat_' + product.category) || product.categoryName) : (product.categoryName || t('cat_' + product.category));
    const isWishlisted = state.wishlist.includes(product.id);
    const badgeText = product.badge ? translateBadge(product.badge) : '';

    const discountPercent = product.oldPrice 
      ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100) 
      : 0;

    qvSelectedSize = (product.sizes && product.sizes.length) ? product.sizes[0] : null;
    qvSelectedColor = (product.colors && product.colors.length) ? product.colors[0] : null;

    content.innerHTML = `
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8 items-start">
        <!-- Image & Showcase Column (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <div class="qv-image-box relative bg-gray-50/40 dark:bg-[#1F1D24] rounded-3xl overflow-hidden p-2.5 border border-gray-100 dark:border-[#2D3139] shadow-sm group">
            <div class="relative overflow-hidden rounded-2xl">
              <img 
                id="qvMainImage" 
                src="${resolveSiteAsset(product.image)}" 
                alt="${primaryName}" 
                class="w-full h-72 sm:h-96 object-cover object-top transition-transform duration-700 group-hover:scale-105"
              />
              
              <!-- Badge -->
              ${badgeText ? `
                <div class="absolute top-3.5 right-3.5 z-10">
                  <span class="text-xs px-3.5 py-1.5 font-bold rounded-full shadow-lg ${
                    product.badge.includes('خصم') ? 'bg-red-600 text-white' : 'badge-gold'
                  }">
                    ${badgeText}
                  </span>
                </div>
              ` : ''}

              ${discountPercent > 0 && !product.badge?.includes('خصم') ? `
                <div class="absolute top-3.5 left-3.5 z-10">
                  <span class="text-xs px-2.5 py-1 font-extrabold rounded-full bg-red-600 text-white shadow-lg">
                    -${discountPercent}%
                  </span>
                </div>
              ` : ''}

              <!-- Bottom Tag -->
              <div class="absolute bottom-3 inset-x-3 flex items-center justify-between pointer-events-none">
                <span class="px-2.5 py-1 rounded-lg bg-black/60 dark:bg-black/80 backdrop-blur-md text-white text-[11px] font-semibold flex items-center gap-1 shadow">
                  <i class="ph-fill ph-sparkle text-amber-400"></i> ${t('exclusivePiece')}
                </span>
                <span class="px-2 py-1 rounded-lg bg-black/60 dark:bg-black/80 backdrop-blur-md text-white text-[11px] font-mono shadow">
                  #${product.id}
                </span>
              </div>
            </div>
          </div>

          <!-- 3 Mini Guarantees in Dark Mode & Light Mode -->
          <div class="grid grid-cols-3 gap-2 sm:gap-2.5 text-center">
            <div class="qv-guarantee-chip p-2.5 rounded-2xl bg-white dark:bg-[#1F1D24] border border-gray-100 dark:border-[#2A2830] flex flex-col items-center justify-center shadow-xs">
              <i class="ph ph-truck text-lg text-[#252B33] mb-1"></i>
              <span class="text-[10px] font-bold text-gray-800 dark:text-gray-200 leading-tight">${t('featQuickShip')}</span>
            </div>
            <div class="qv-guarantee-chip p-2.5 rounded-2xl bg-white dark:bg-[#1F1D24] border border-gray-100 dark:border-[#2A2830] flex flex-col items-center justify-center shadow-xs">
              <i class="ph ph-seal-check text-lg text-emerald-500 mb-1"></i>
              <span class="text-[10px] font-bold text-gray-800 dark:text-gray-200 leading-tight">${t('feat100Orig')}</span>
            </div>
            <div class="qv-guarantee-chip p-2.5 rounded-2xl bg-white dark:bg-[#1F1D24] border border-gray-100 dark:border-[#2A2830] flex flex-col items-center justify-center shadow-xs">
              <i class="ph ph-arrows-clockwise text-lg text-blue-500 mb-1"></i>
              <span class="text-[10px] font-bold text-gray-800 dark:text-gray-200 leading-tight">${t('featEasyReturn')}</span>
            </div>
          </div>
        </div>

        <!-- Product Information Column (7 cols) -->
        <div class="lg:col-span-7 flex flex-col justify-between space-y-5">
          <div>
            <!-- Category and Rating -->
            <div class="flex items-center justify-between gap-3 mb-2">
              <span class="px-3 py-1 rounded-full text-xs font-bold bg-gray-50 dark:bg-gray-950/60 text-[#252B33] dark:text-gray-300 border border-gray-200/80 dark:border-gray-900/40">
                ${categoryName}
              </span>
              
              <div class="flex items-center gap-1.5 text-xs">
                <div class="flex items-center text-amber-400">
                  <i class="ph-fill ph-star text-sm"></i>
                </div>
                <span class="font-extrabold text-gray-900 dark:text-white">${product.rating || '5.0'}</span>
                <span class="text-gray-400 dark:text-gray-400 font-medium">(${product.reviewsCount || 1} ${t('reviews')})</span>
              </div>
            </div>

            <!-- Title & Subtitle -->
            <h2 class="text-2xl sm:text-3xl font-black text-gray-900 dark:text-white leading-tight mb-1">
              ${primaryName}
            </h2>
            ${secondaryName ? `
              <p class="text-xs font-serif-lux italic text-[#252B33] dark:text-[#737A83] tracking-wider mb-3">
                ${secondaryName}
              </p>
            ` : ''}

            <!-- Price Card -->
            <div class="qv-price-card flex items-baseline flex-wrap gap-3 py-3.5 px-4 rounded-2xl bg-gradient-to-r from-gray-50/80 via-white to-gray-50/40 dark:from-[#252B33] dark:to-[#1F1D24] border border-gray-100 dark:border-[#2D3139] mb-5 shadow-xs">
              <span class="text-3xl font-black text-[#252B33] dark:text-[#737A83] tracking-tight">
                ${product.price} <span class="text-sm font-bold text-gray-600 dark:text-gray-300">${t('currency')}</span>
              </span>
              ${product.oldPrice ? `
                <span class="text-base text-gray-400 dark:text-gray-500 line-through font-medium">
                  ${product.oldPrice} ${t('currency')}
                </span>
                <span class="text-xs font-extrabold text-red-600 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200/60 dark:border-red-900/50 px-2.5 py-1 rounded-lg">
                  ${t('saved')} ${product.oldPrice - product.price} ${t('currency')}
                </span>
              ` : ''}
            </div>

            <!-- Description Box -->
            <div class="mb-5">
              <label class="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5 flex items-center gap-1.5">
                <i class="ph ph-sparkle text-sm text-[#252B33]"></i>
                <span>${t('qvDescription')}</span>
              </label>
              <div class="qv-description-box p-3.5 rounded-2xl bg-gray-50/90 dark:bg-[#1F1D24] border border-gray-100 dark:border-[#2A2830] text-xs sm:text-sm text-gray-600 dark:text-[#CBD0D7] leading-relaxed">
                ${description}
              </div>
            </div>

            <!-- Size Selector -->
            ${product.sizes && product.sizes.length ? `
              <div class="mb-4">
                <label class="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">${t('qvSize')}</label>
                <div class="flex flex-wrap gap-2" id="qvSizes">
                  ${product.sizes.map((size, idx) => `
                    <button 
                      type="button" 
                      onclick="selectQvSize(this, '${size}')" 
                      class="qv-size-btn px-4 py-2 text-xs font-semibold rounded-xl border transition ${idx === 0 ? 'active' : ''}"
                    >
                      ${translateOption(size)}
                    </button>
                  `).join('')}
                </div>
              </div>
            ` : ''}

            <!-- Color Selector -->
            ${product.colors && product.colors.length ? `
              <div class="mb-5">
                <label class="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">${t('qvColor')}</label>
                <div class="flex flex-wrap gap-2" id="qvColors">
                  ${product.colors.map((color, idx) => `
                    <button 
                      type="button" 
                      onclick="selectQvColor(this, '${color}')" 
                      class="qv-color-btn px-4 py-2 text-xs font-semibold rounded-xl border transition ${idx === 0 ? 'active' : ''}"
                    >
                      ${translateOption(color)}
                    </button>
                  `).join('')}
                </div>
              </div>
            ` : ''}
          </div>

          <!-- Quantity and Action Buttons Footer -->
          <div class="pt-4 border-t border-gray-100 dark:border-[#2A2830] space-y-4">
            
            <!-- Quantity & Stock Row -->
            <div class="flex items-center justify-between gap-4">
              <div class="flex items-center gap-3">
                <label class="text-xs font-bold text-gray-700 dark:text-gray-300">${t('qvQty')}</label>
                <div class="qv-qty-box flex items-center border border-gray-200 dark:border-[#2A2830] rounded-xl overflow-hidden bg-white dark:bg-[#1F1D24] shadow-xs">
                  <button onclick="changeQvQty(-1)" class="qv-qty-btn w-9 h-9 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-950/50 hover:text-[#252B33] font-bold transition">
                    <i class="ph ph-minus text-sm"></i>
                  </button>
                  <span id="qvQuantity" class="w-10 text-center text-sm font-extrabold text-gray-900 dark:text-white">1</span>
                  <button onclick="changeQvQty(1)" class="qv-qty-btn w-9 h-9 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-950/50 hover:text-[#252B33] font-bold transition">
                    <i class="ph ph-plus text-sm"></i>
                  </button>
                </div>
              </div>

              <!-- Stock Availability Badge -->
              <div>
                ${product.stock > 5 ? `
                  <span class="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2.5 py-1 rounded-lg border border-emerald-200/50 dark:border-emerald-900/40">
                    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    ${t('available')} ${product.stock} ${t('piece')}
                  </span>
                ` : product.stock > 0 ? `
                  <span class="inline-flex items-center gap-1.5 text-xs font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-200/50 dark:border-amber-900/40">
                    <span class="w-2 h-2 rounded-full bg-amber-500"></span>
                    ${t('stockWarning', { n: product.stock })}
                  </span>
                ` : `
                  <span class="inline-flex items-center gap-1.5 text-xs font-bold text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 px-2.5 py-1 rounded-lg border border-red-200/50 dark:border-red-900/40">
                    ${t('outOfStock')}
                  </span>
                `}
              </div>
            </div>

            <!-- Add to Cart & Wishlist Buttons -->
            <div class="flex gap-3">
              <button 
                onclick="addQvToCart()" 
                class="flex-1 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#252B33] to-[#414852] hover:from-[#414852] hover:to-[#737A83] text-white font-bold text-sm shadow-lg shadow-gray-950/30 flex items-center justify-center gap-2.5 transition-all duration-300 hover:scale-[1.02] active:scale-95"
              >
                <i class="ph ph-shopping-bag text-xl"></i>
                <span>${t('qvAddToCart')}</span>
              </button>

              <button 
                onclick="toggleWishlist(${product.id}); updateQvWishlistBtn(${product.id});" 
                id="qvWishlistBtn"
                class="p-3.5 rounded-2xl border border-gray-200 dark:border-[#2D3139] bg-white dark:bg-[#1F1D24] hover:bg-gray-50 dark:hover:bg-gray-950/40 text-[#252B33] dark:text-gray-400 shadow-sm transition hover:scale-105 active:scale-95"
                title="${t('qvWishlist')}"
              >
                ${isWishlisted ? '<i class="ph-fill ph-heart text-2xl text-gray-500"></i>' : '<i class="ph ph-heart text-2xl"></i>'}
              </button>
            </div>

          </div>
        </div>
      </div>
    `;

    disableStaticCommerceActions(content);

    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  } catch (err) {
    console.error('Error opening quick view:', err);
  }
}

let qvSelectedSize = null;
let qvSelectedColor = null;

function selectQvSize(btn, size) {
  document.querySelectorAll('.qv-size-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  qvSelectedSize = size;
}

function selectQvColor(btn, color) {
  document.querySelectorAll('.qv-color-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  qvSelectedColor = color;
}

function updateQvWishlistBtn(productId) {
  const btn = document.getElementById('qvWishlistBtn');
  if (!btn) return;
  const isWishlisted = state.wishlist.includes(productId);
  btn.innerHTML = isWishlisted 
    ? '<i class="ph-fill ph-heart text-2xl text-gray-500"></i>' 
    : '<i class="ph ph-heart text-2xl"></i>';
}

function changeQvQty(delta) {
  const qtySpan = document.getElementById('qvQuantity');
  if (!qtySpan) return;
  let current = parseInt(qtySpan.textContent) || 1;
  current = Math.max(1, current + delta);
  if (state.activeProduct && state.activeProduct.stock && current > state.activeProduct.stock) {
    showToast(`الكمية المتاحة حالياً هي ${state.activeProduct.stock} فقط`, 'info');
    current = state.activeProduct.stock;
  }
  qtySpan.textContent = current;
}

function addQvToCart() {
  if (IS_GITHUB_PAGES) {
    showToast('هذه نسخة عرض فقط ولا تستقبل طلبات.', 'info');
    return;
  }
  if (!state.activeProduct) return;
  const qty = parseInt(document.getElementById('qvQuantity').textContent) || 1;
  const size = qvSelectedSize || (state.activeProduct.sizes ? state.activeProduct.sizes[0] : 'قياسي');
  const color = qvSelectedColor || (state.activeProduct.colors ? state.activeProduct.colors[0] : 'اللون الأساسي');

  addToCart(state.activeProduct, qty, size, color);
  closeQuickView();
  openCartDrawer();
}

function closeQuickView() {
  const modal = document.getElementById('quickViewModal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Cart Drawer Operations
function openCartDrawer() {
  renderCartItems();
  const drawer = document.getElementById('cartDrawer');
  if (drawer) {
    drawer.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeCartDrawer() {
  const drawer = document.getElementById('cartDrawer');
  if (drawer) {
    drawer.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Render Cart Items inside Drawer
function renderCartItems() {
  const container = document.getElementById('cartItemsList');
  const emptyState = document.getElementById('cartEmptyState');
  const footer = document.getElementById('cartDrawerFooter');

  if (!container) return;

  if (state.cart.length === 0) {
    container.innerHTML = '';
    if (emptyState) emptyState.classList.remove('hidden');
    if (footer) footer.classList.add('hidden');
    return;
  }

  if (emptyState) emptyState.classList.add('hidden');
  if (footer) footer.classList.remove('hidden');

  const isEn = getLang() === 'en';

  container.innerHTML = state.cart.map((item, index) => {
    const itemName = isEn ? (item.nameEn || item.name) : item.name;
    const sizeVal = translateOption(item.selectedSize);
    const colorVal = translateOption(item.selectedColor);

    return `
      <div class="flex items-center gap-4 py-4 border-b border-gray-100 dark:border-gray-800 last:border-none">
        <img src="${item.image}" alt="${itemName}" class="w-16 h-20 object-cover object-top rounded-xl bg-gray-50 dark:bg-[#252B33] border border-gray-100 dark:border-gray-800">
        
        <div class="flex-1 min-w-0">
          <h4 class="text-sm font-bold text-gray-800 dark:text-gray-100 truncate mb-1">${itemName}</h4>
          <div class="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 mb-2">
            <span>${t('sizeLabel')} <b class="text-gray-700 dark:text-gray-200">${sizeVal}</b></span>
            <span>•</span>
            <span>${t('colorLabel')} <b class="text-gray-700 dark:text-gray-200">${colorVal}</b></span>
          </div>
          <div class="text-sm font-extrabold text-[#252B33] dark:text-[#737A83]">
            ${item.price} ${t('currency')}
          </div>
        </div>

        <!-- Quantity Controls -->
        <div class="flex flex-col items-end gap-2">
          <button onclick="removeCartItem(${index})" class="text-gray-400 hover:text-red-500 transition" title="حذف">
            <i class="ph ph-trash text-lg"></i>
          </button>
          <div class="flex items-center border border-gray-200 dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-[#252B33]">
            <button onclick="updateCartItemQty(${index}, -1)" class="w-7 h-7 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-[#252B33] text-sm font-bold">-</button>
            <span class="w-7 text-center text-xs font-bold text-gray-800 dark:text-white">${item.quantity}</span>
            <button onclick="updateCartItemQty(${index}, 1)" class="w-7 h-7 flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-[#252B33] text-sm font-bold">+</button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  calculateCartTotals();
}

function updateCartItemQty(index, delta) {
  if (!state.cart[index]) return;
  state.cart[index].quantity += delta;
  if (state.cart[index].quantity <= 0) {
    state.cart.splice(index, 1);
  }
  saveCart();
  updateCartBadge();
  renderCartItems();
}

function removeCartItem(index) {
  state.cart.splice(index, 1);
  saveCart();
  updateCartBadge();
  renderCartItems();
  showToast(t('cartItemRemoved'), 'info');
}

// Calculate Cart Totals
function calculateCartTotals() {
  const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = Math.round((subtotal * state.discountPercent) / 100);
  // Free shipping if subtotal after discount > 300 SAR
  const shipping = (subtotal - discountAmount) >= 300 || subtotal === 0 ? 0 : 25;
  const total = Math.max(0, subtotal - discountAmount + shipping);

  document.getElementById('cartSubtotal').textContent = `${subtotal} ${t('currency')}`;
  document.getElementById('cartDiscount').textContent = `-${discountAmount} ${t('currency')}`;
  document.getElementById('cartShipping').textContent = shipping === 0 ? t('freeShipping') : `${shipping} ${t('currency')}`;
  document.getElementById('cartTotal').textContent = `${total} ${t('currency')}`;

  return { subtotal, discountAmount, shipping, total };
}

// Handle Coupon Code
function handleApplyCoupon(e) {
  e.preventDefault();
  const input = document.getElementById('couponInput');
  const code = input ? input.value.trim().toUpperCase() : '';

  if (code === 'ELEGANCE10') {
    state.appliedCoupon = code;
    state.discountPercent = 10;
    localStorage.setItem('elegance_coupon', code);
    showToast(t('coupon10'), 'success');
  } else if (code === 'ELEGANCE20') {
    state.appliedCoupon = code;
    state.discountPercent = 20;
    localStorage.setItem('elegance_coupon', code);
    showToast(t('coupon20'), 'success');
  } else {
    showToast(t('couponInvalid'), 'error');
    return;
  }

  calculateCartTotals();
}

// Checkout Modal
function openCheckoutModal() {
  if (IS_GITHUB_PAGES) {
    showToast('هذه نسخة عرض ثابتة؛ إتمام الطلبات غير متاح هنا.', 'info');
    return;
  }
  if (state.cart.length === 0) {
    showToast(t('cartEmpty2'), 'info');
    return;
  }
  closeCartDrawer();
  const totals = calculateCartTotals();
  document.getElementById('checkoutFinalTotal').textContent = `${totals.total} ${t('currency')}`;
  
  // Pre-fill user data if logged in
  if (state.currentUser) {
    const nameInput = document.getElementById('custName');
    const emailInput = document.getElementById('custEmail');
    if (nameInput && !nameInput.value) {
      nameInput.value = state.currentUser.name || '';
    }
    if (emailInput && !emailInput.value) {
      emailInput.value = state.currentUser.email || '';
    }
  }

  const modal = document.getElementById('checkoutModal');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}

function closeCheckoutModal() {
  const modal = document.getElementById('checkoutModal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Handle Checkout Submission
async function handleCheckoutSubmit(e) {
  e.preventDefault();

  const submitBtn = document.getElementById('checkoutSubmitBtn');
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <i class="ph ph-spinner animate-spin text-xl"></i>
      <span>${t('processingOrder')}</span>
    `;
  }

  const totals = calculateCartTotals();

  const customerData = {
    name: document.getElementById('custName').value.trim(),
    phone: document.getElementById('custPhone').value.trim(),
    email: document.getElementById('custEmail').value.trim(),
    city: document.getElementById('custCity').value.trim(),
    address: document.getElementById('custAddress').value.trim()
  };

  const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cod';

  const orderPayload = {
    customer: customerData,
    items: state.cart,
    subtotal: totals.subtotal,
    discount: totals.discountAmount,
    shipping: totals.shipping,
    total: totals.total,
    paymentMethod: paymentMethod,
    coupon: state.appliedCoupon
  };

  try {
    const headers = { 'Content-Type': 'application/json' };
    if (state.token) {
      headers['Authorization'] = `Bearer ${state.token}`;
    }

    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(orderPayload)
    });

    const data = await res.json();

    if (data.success) {
      // Clear Cart
      state.cart = [];
      saveCart();
      updateCartBadge();

      closeCheckoutModal();
      showOrderSuccess(data.data);
    } else {
      showToast(data.error || t('orderError'), 'error');
    }
  } catch (err) {
    console.error('Checkout error:', err);
    showToast(t('serverConnectError'), 'error');
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = `
        <i class="ph ph-check-circle text-xl"></i>
        <span>${t('confirmOrder')}</span>
      `;
    }
  }
}

// Order Success Dialog
function showOrderSuccess(order) {
  const payLabel = order.paymentMethod === 'cod' ? t('paymentCod') : t('paymentCard');
  Swal.fire({
    title: t('orderSuccess'),
    html: `
      <div class="text-right py-2 leading-relaxed text-sm">
        <p class="font-bold text-[#252B33] text-base mb-2">${t('orderNumLabel')}${order.id}</p>
        <p class="text-gray-700">${t('orderThankYou')} <b>${order.customer.name}</b> ${t('orderThankYouFor')}</p>
        <p class="text-gray-500 text-xs mt-1">${t('orderShipMsg')} <b>${order.customer.city}</b> ${t('orderShipSoon')}</p>
        <div class="mt-4 p-3 bg-gray-50 rounded-xl text-center text-[#252B33] font-bold">
          ${t('orderTotalLabel')} ${order.total} ${t('currency')} (${payLabel})
        </div>
      </div>
    `,
    icon: 'success',
    confirmButtonText: t('continueShopping'),
    confirmButtonColor: '#252B33',
    customClass: {
      popup: 'rounded-2xl',
      confirmButton: 'rounded-xl px-6 py-2.5 font-bold'
    }
  });
}

// Wishlist Drawer
function openWishlistDrawer() {
  const drawer = document.getElementById('wishlistDrawer');
  const container = document.getElementById('wishlistItemsList');
  const empty = document.getElementById('wishlistEmptyState');

  if (!drawer || !container) return;

  const wishlistedProducts = state.products.filter(p => state.wishlist.includes(p.id));

  if (wishlistedProducts.length === 0) {
    container.innerHTML = '';
    if (empty) empty.classList.remove('hidden');
  } else {
    if (empty) empty.classList.add('hidden');
    const isEn = getLang() === 'en';
    container.innerHTML = wishlistedProducts.map(p => {
      const pName = isEn ? (p.nameEn || p.name) : p.name;
      return `
        <div class="flex items-center gap-4 py-4 border-b border-gray-100 dark:border-gray-800 last:border-none">
          <img src="${p.image}" alt="${pName}" class="w-16 h-20 object-cover object-top rounded-xl bg-gray-50 dark:bg-[#1F1D24] border border-gray-100 dark:border-gray-800">
          <div class="flex-1 min-w-0">
            <h4 class="text-sm font-bold text-gray-800 dark:text-gray-100 truncate mb-1">${pName}</h4>
            <div class="text-sm font-extrabold text-[#252B33] dark:text-[#737A83] mb-2">${p.price} ${t('currency')}</div>
            <button 
              onclick="quickAddToCart(${p.id}); toggleWishlist(${p.id}); openWishlistDrawer();" 
              class="text-xs bg-gray-900 dark:bg-[#252B33] hover:bg-[#252B33] dark:hover:bg-[#252B33] text-white px-3 py-1.5 rounded-lg transition font-medium"
            >
              ${t('moveToCart')}
            </button>
          </div>
          <button onclick="toggleWishlist(${p.id}); openWishlistDrawer();" class="text-gray-400 hover:text-red-500 transition" title="حذف">
            <i class="ph ph-trash text-lg"></i>
          </button>
        </div>
      `;
    }).join('');
  }

  drawer.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeWishlistDrawer() {
  const drawer = document.getElementById('wishlistDrawer');
  if (drawer) {
    drawer.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Theme Toggle Functions
function toggleTheme() {
  const isDark = document.documentElement.classList.toggle('dark');
  localStorage.setItem('elegance_theme', isDark ? 'dark' : 'light');
  updateThemeIcon();
}

function updateThemeIcon() {
  const isDark = document.documentElement.classList.contains('dark');
  const btn = document.getElementById('themeToggleBtn');
  if (btn) {
    btn.innerHTML = isDark 
      ? '<i class="ph ph-sun text-xl text-amber-400"></i>' 
      : '<i class="ph ph-moon text-xl text-gray-700"></i>';
  }
}

// Toast Notification
function showToast(message, type = 'success') {
  const Toast = Swal.mixin({
    toast: true,
    position: 'bottom-start',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener('mouseenter', Swal.stopTimer);
      toast.addEventListener('mouseleave', Swal.resumeTimer);
    }
  });

  Toast.fire({
    icon: type,
    title: message
  });
}

// ================= AUTHENTICATION & PERMISSIONS =================

// Check current user login status from token
async function checkAuthStatus() {
  if (!state.token) {
    state.currentUser = null;
    renderAuthUI();
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: {
        'Authorization': `Bearer ${state.token}`
      }
    });

    const data = await res.json();
    if (data.success && data.user) {
      state.currentUser = data.user;
    } else {
      // Invalid/expired token
      state.currentUser = null;
      state.token = null;
      localStorage.removeItem('elegance_token');
    }
  } catch (err) {
    console.warn('Auth check error:', err);
  }

  renderAuthUI();
}

// Render Header User Info & Role Badge
function renderAuthUI() {
  const loginBtn = document.getElementById('loginBtn');
  const userProfileBtn = document.getElementById('userProfileBtn');
  const quickAdminLink = document.getElementById('quickAdminLink');
  const menuAdminLink = document.getElementById('menuAdminLink');

  if (!loginBtn || !userProfileBtn) return;

  if (state.currentUser) {
    loginBtn.classList.add('hidden');
    userProfileBtn.classList.remove('hidden');

    const avatar = document.getElementById('navUserAvatar');
    const nameEl = document.getElementById('navUserName');
    const badgeEl = document.getElementById('navUserRoleBadge');

    const menuName = document.getElementById('menuUserName');
    const menuEmail = document.getElementById('menuUserEmail');
    const menuRole = document.getElementById('menuUserRole');

    if (avatar) avatar.src = state.currentUser.picture || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80';
    if (nameEl) nameEl.textContent = state.currentUser.name;
    
    const roleText = state.currentUser.role === 'admin' ? t('adminRoleLabel') : t('customerRoleLabel');
    if (badgeEl) badgeEl.textContent = roleText;

    if (menuName) menuName.textContent = state.currentUser.name;
    if (menuEmail) menuEmail.textContent = state.currentUser.email;
    if (menuRole) menuRole.textContent = `${t('rolePrefix')} ${roleText}`;

    // Permissions visibility - ONLY visible for Admin role
    const isAdmin = state.currentUser.role === 'admin';
    const footerAdminItem = document.getElementById('footerAdminItem');

    if (quickAdminLink) quickAdminLink.style.display = isAdmin ? 'inline-flex' : 'none';
    if (menuAdminLink) menuAdminLink.style.display = isAdmin ? 'flex' : 'none';
    if (footerAdminItem) footerAdminItem.style.display = isAdmin ? 'block' : 'none';
  } else {
    loginBtn.classList.remove('hidden');
    userProfileBtn.classList.add('hidden');
    const footerAdminItem = document.getElementById('footerAdminItem');
    if (quickAdminLink) quickAdminLink.style.display = 'none';
    if (menuAdminLink) menuAdminLink.style.display = 'none';
    if (footerAdminItem) footerAdminItem.style.display = 'none';
  }
}

// Toggle Dropdown Menu
function toggleUserDropdown() {
  const menu = document.getElementById('userDropdownMenu');
  if (menu) {
    menu.classList.toggle('hidden');
  }
}

// Close dropdown on outside click
document.addEventListener('click', (e) => {
  const wrapper = document.getElementById('userMenuWrapper');
  const menu = document.getElementById('userDropdownMenu');
  if (wrapper && menu && !wrapper.contains(e.target)) {
    menu.classList.add('hidden');
  }
});

// Login Modal
function openLoginModal() {
  const modal = document.getElementById('loginModal');
  if (modal) {
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
    renderGoogleButtonIfAvailable();
  }
}

function closeLoginModal() {
  const modal = document.getElementById('loginModal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Initialize Google Identity Services
async function initGoogleAuth() {
  try {
    const res = await fetch(`${API_BASE}/auth/google-config`);
    const config = await res.json();
    state.googleClientId = config.clientId;
    state.googleEnabled = Boolean(config.googleEnabled || (config.clientId && config.clientId !== 'DEMO_GOOGLE_CLIENT_ID'));
    state.demoMode = Boolean(config.demoMode);
    document.getElementById('demoLoginDivider')?.classList.toggle('hidden', !state.demoMode);
    document.getElementById('demoLoginOptions')?.classList.toggle('hidden', !state.demoMode);
    document.getElementById('googleFallbackButton')?.classList.toggle('hidden', state.googleEnabled);
    renderGoogleButtonIfAvailable();
  } catch (e) {
    state.googleClientId = null;
    state.googleEnabled = false;
  }
}

function renderGoogleButtonIfAvailable() {
  if (!state.googleEnabled || !state.googleClientId) return;
  if (!window.google?.accounts?.id) {
    if (googleButtonRetryCount++ < 25) setTimeout(renderGoogleButtonIfAvailable, 200);
    return;
  }

  try {
    if (!googleAuthInitialized) {
      google.accounts.id.initialize({
        client_id: state.googleClientId,
        callback: handleGoogleCredentialResponse
      });
      googleAuthInitialized = true;
    }

    const container = document.getElementById('googleBtnContainer');
    if (container && !googleButtonRendered) {
      container.replaceChildren();
      google.accounts.id.renderButton(container, {
        theme: 'outline',
        size: 'large',
        text: 'signin_with',
        shape: 'pill',
        locale: 'ar'
      });
      googleButtonRendered = true;
      document.getElementById('googleFallbackButton')?.classList.add('hidden');
    }
  } catch (e) {
    console.warn('Google GIS init error:', e);
  }
}

// Handle Google Login response from GIS
async function handleGoogleCredentialResponse(response) {
  if (!response || !response.credential) return;

  try {
    const res = await fetch(`${API_BASE}/auth/google`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ credential: response.credential })
    });

    const data = await res.json();
    if (data.success) {
      state.token = data.token;
      state.currentUser = data.user;
      localStorage.setItem('elegance_token', data.token);

      closeLoginModal();
      renderAuthUI();

      Swal.fire({
        icon: 'success',
        title: `مرحباً بكِ ${data.user.name}! 🌸`,
        text: `تم تسجيل الدخول بنجاح بحساب Google (الرتبة: ${data.user.role === 'admin' ? 'مديرة النظام' : 'عميلة'})`,
        showConfirmButton: false,
        timer: 2500
      });
    } else {
      showToast(data.error || 'فشل تسجيل الدخول بحساب جوجل', 'error');
    }
  } catch (err) {
    console.error('Google auth processing error:', err);
    showToast('حدث خطأ أثناء معالجة تسجيل الدخول', 'error');
  }
}

// Trigger Google Auth button click
function triggerGoogleAuth() {
  if (!state.googleEnabled || !state.googleClientId) {
    showToast('تسجيل Google الحقيقي غير مهيأ بعد. استخدم دخول التجربة أو أضف إعداد OAuth للموقع.', 'error');
    return;
  }

  renderGoogleButtonIfAvailable();
  showToast('استخدم زر Google الرسمي الظاهر أعلى هذه الرسالة لتسجيل الدخول.', 'info');
}

// Fast Demo Login by Role (Admin or Customer)
async function loginAsDemo(role) {
  if (!state.demoMode) return;
  try {
    const res = await fetch(`${API_BASE}/auth/demo-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role })
    });

    const data = await res.json();
    if (data.success) {
      state.token = data.token;
      state.currentUser = data.user;
      localStorage.setItem('elegance_token', data.token);

      closeLoginModal();
      renderAuthUI();

      const roleDesc = data.user.role === 'admin' 
        ? 'تم الدخول كـ (مديرة النظام) - لديكِ كافة صلاحيات الإدارة وإضافة وتعديل المنتجات والإحصائيات!' 
        : 'تم الدخول كـ (عميلة المتجر) - يمكنكِ الشراء، إدارة السلة، وتتبع طلباتكِ الخاصة.';

      Swal.fire({
        icon: 'success',
        title: `أهلاً بكِ ${data.user.name}! 👑`,
        text: roleDesc,
        confirmButtonColor: '#252B33',
        confirmButtonText: 'رائع، استمرار'
      });
    }
  } catch (err) {
    console.error('Demo login error:', err);
    showToast('تعذر تسجيل الدخول التجريبي', 'error');
  }
}

// Logout
function logout() {
  state.token = null;
  state.currentUser = null;
  localStorage.removeItem('elegance_token');
  renderAuthUI();

  showToast(t('logoutSuccess'), 'info');
}

// My Orders Modal
async function openMyOrdersModal() {
  const modal = document.getElementById('myOrdersModal');
  const container = document.getElementById('myOrdersList');
  if (!modal || !container) return;

  if (!state.currentUser) {
    showToast(t('loginFirst'), 'info');
    openLoginModal();
    return;
  }

  container.innerHTML = `
    <div class="py-12 text-center text-gray-400">
      <i class="ph ph-spinner animate-spin text-3xl text-[#252B33]"></i>
      <p class="text-xs mt-2">${t('myOrdersLoading')}</p>
    </div>
  `;

  modal.classList.remove('hidden');
  document.body.style.overflow = 'hidden';

  try {
    const res = await fetch(`${API_BASE}/orders`, {
      headers: {
        'Authorization': `Bearer ${state.token}`
      }
    });

    const data = await res.json();
    if (data.success && data.data) {
      const orders = data.data;
      if (orders.length === 0) {
        container.innerHTML = `
          <div class="py-12 text-center">
            <div class="w-16 h-16 mx-auto mb-3 bg-gray-50 dark:bg-gray-950/40 rounded-full flex items-center justify-center text-gray-300">
              <i class="ph ph-receipt text-3xl"></i>
            </div>
            <h4 class="font-bold text-gray-800 dark:text-white text-sm mb-1">${t('noOrders')}</h4>
            <p class="text-xs text-gray-400">${t('noOrdersDesc')}</p>
          </div>
        `;
        return;
      }

      const statusColors = {
        'جديد': 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
        'قيد المعالجة': 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
        'تم الشحن': 'bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
        'تم التوصيل': 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
        'ملغي': 'bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800'
      };

      const isEn = getLang() === 'en';

      container.innerHTML = orders.map(o => `
        <div class="p-5 rounded-2xl border border-gray-100 dark:border-gray-800 bg-[#fdf9fa] dark:bg-[#252B33] space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="font-bold text-sm text-gray-900 dark:text-white">${t('orderNum')}${o.id}</span>
              <span class="text-[11px] text-gray-400 font-mono">${new Date(o.createdAt).toLocaleDateString(isEn ? 'en-US' : 'ar-SA')}</span>
            </div>
            <span class="text-xs font-bold px-3 py-1 rounded-full border ${statusColors[o.status] || 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'}">
              ${o.status}
            </span>
          </div>

          <div class="text-xs text-gray-600 dark:text-gray-300 space-y-1">
            <p>${t('deliverTo')} <b class="text-gray-900 dark:text-white">${o.customer.city}</b> - ${o.customer.address}</p>
            <p>${t('paymentLabel')} <b class="text-gray-900 dark:text-white">${o.paymentMethod === 'cod' ? t('codLabel') : t('cardLabel')}</b></p>
          </div>

          <div class="pt-3 border-t border-gray-200/60 dark:border-gray-800 flex items-center justify-between">
            <span class="text-xs text-gray-500 dark:text-gray-400">${o.items ? o.items.length : 0} ${t('items')}</span>
            <span class="text-base font-extrabold text-[#252B33] dark:text-[#737A83]">${o.total} ${t('currency')}</span>
          </div>
        </div>
      `).join('');
    }
  } catch (err) {
    console.error('Error fetching my orders:', err);
    container.innerHTML = `<p class="text-center text-red-500 text-xs py-8">${t('fetchOrdersError')}</p>`;
  }
}

function closeMyOrdersModal() {
  const modal = document.getElementById('myOrdersModal');
  if (modal) {
    modal.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }
}

// Admin Dashboard Logic for Élégance Her Store

const API_BASE = '/api';
let allProducts = [];
let allOrders = [];
let allUsers = [];
let currentAdmin = null;
let pendingImageUploads = 0;

document.addEventListener('DOMContentLoaded', () => {
  initAdmin();
});

// Initialize Admin Panel with Security Guard
async function initAdmin() {
  updateAdminThemeIcon();
  try {
    const authConfig = await fetch(`${API_BASE}/auth/google-config`, { cache: 'no-store' }).then(res => res.json());
    document.getElementById('adminDemoLoginBtn')?.classList.toggle('hidden', !authConfig.demoMode);
  } catch (err) {
    document.getElementById('adminDemoLoginBtn')?.classList.add('hidden');
  }
  const token = localStorage.getItem('elegance_token');

  // Verify Admin Role & Permissions
  if (!token) {
    showAccessDenied();
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const data = await res.json();
    if (!data.success || !data.user || data.user.role !== 'admin') {
      showAccessDenied();
      return;
    }

    currentAdmin = data.user;
    showAdminContent();

    // Render Admin Header Info
    const adminAvatar = document.getElementById('adminAvatar');
    const adminName = document.getElementById('adminName');
    if (adminAvatar) adminAvatar.src = currentAdmin.picture || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80';
    if (adminName) adminName.textContent = currentAdmin.name;

    // Load Data
    await Promise.all([
      loadStats(),
      loadProducts(),
      loadOrders(),
      loadUsers(),
      loadAdminBranding()
    ]);

    setupEventListeners();
  } catch (err) {
    console.error('Admin init error:', err);
    showAccessDenied();
  }
}

async function loadAdminBranding() {
  try {
    const res = await fetch(`${API_BASE}/products/settings`, { cache: 'no-store' });
    const data = await res.json();
    if (data.success && data.data) applyAdminBrandSettings(data.data);
  } catch (err) {
    console.warn('Could not load store branding');
  }
}

function applyAdminBrandSettings(settings) {
  const siteName = settings.siteName?.trim() || 'أناقة هير';
  const brandName = document.getElementById('adminBrandName');
  if (brandName) brandName.textContent = siteName;
  const dashboardBrandName = document.getElementById('dashboardBrandName');
  if (dashboardBrandName) dashboardBrandName.textContent = `${siteName} · إدارة المتجر`;
  const logo = document.getElementById('adminBrandLogo');
  const icon = document.getElementById('adminBrandIcon');
  const logoContainer = document.getElementById('adminBrandLogoContainer');
  if (settings.logoUrl) {
    if (logo) { logo.src = settings.logoUrl; logo.classList.remove('hidden'); }
    if (icon) icon.classList.add('hidden');
    if (logoContainer) logoContainer.style.background = 'transparent';
  } else {
    if (logo) { logo.removeAttribute('src'); logo.classList.add('hidden'); }
    if (icon) icon.classList.remove('hidden');
    if (logoContainer) logoContainer.style.background = '';
  }
  document.title = `لوحة الإدارة والتحكم | ${siteName}`;
}

window.addEventListener('storage', event => {
  if (event.key !== 'elegance_site_settings' || !event.newValue) return;
  try {
    applyAdminBrandSettings(JSON.parse(event.newValue));
  } catch (err) {
    console.warn('Could not read updated site settings');
  }
});

// Show Access Denied Guard
function showAccessDenied() {
  const content = document.getElementById('adminMainContent');
  const denied = document.getElementById('accessDeniedCard');
  if (content) content.classList.add('hidden');
  if (denied) denied.classList.remove('hidden');
}

// Show Admin Dashboard
function showAdminContent() {
  const content = document.getElementById('adminMainContent');
  const denied = document.getElementById('accessDeniedCard');
  if (content) content.classList.remove('hidden');
  if (denied) denied.classList.add('hidden');
}

// Fast Admin Demo Login from access denied page
async function loginAsAdminDemo() {
  if (document.getElementById('adminDemoLoginBtn')?.classList.contains('hidden')) return;
  try {
    const res = await fetch(`${API_BASE}/auth/demo-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role: 'admin' })
    });
    const data = await res.json();
    if (data.success) {
      localStorage.setItem('elegance_token', data.token);
      Swal.fire({
        icon: 'success',
        title: 'تم تسجيل الدخول كمديرة النظام بنجاح 👑',
        showConfirmButton: false,
        timer: 1500
      }).then(() => {
        initAdmin();
      });
    }
  } catch (e) {
    Swal.fire('خطأ', 'تعذر تسجيل الدخول', 'error');
  }
}

// Admin Logout
function adminLogout() {
  localStorage.removeItem('elegance_token');
  window.location.href = '/';
}

// Theme Toggle Logic
function toggleTheme() {
  const isDark = document.documentElement.classList.toggle('dark');
  localStorage.setItem('elegance_theme', isDark ? 'dark' : 'light');
  updateAdminThemeIcon();
}

function updateAdminThemeIcon() {
  const isDark = document.documentElement.classList.contains('dark');
  const btn = document.getElementById('adminThemeToggleBtn');
  if (btn) {
    btn.innerHTML = isDark 
      ? '<i class="ph ph-sun text-lg text-amber-400"></i>' 
      : '<i class="ph ph-moon text-lg text-gray-600"></i>';
  }
}

function setupEventListeners() {
  // Product Search
  const searchInput = document.getElementById('adminProductSearch');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase();
      const filtered = allProducts.filter(p => 
        p.name.toLowerCase().includes(q) || 
        (p.categoryName && p.categoryName.toLowerCase().includes(q))
      );
      renderProductsTable(filtered);
    });
  }

  // Add Product Form
  const productForm = document.getElementById('productForm');
  if (productForm) {
    productForm.addEventListener('submit', handleSaveProduct);
  }
}

// Helper to get auth header
function getAuthHeaders() {
  const token = localStorage.getItem('elegance_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };
}

// Switch Tabs (Products / Orders / Users / Settings)
function switchAdminTab(tab) {
  const tabBtnProducts = document.getElementById('tabBtnProducts');
  const tabBtnOrders = document.getElementById('tabBtnOrders');
  const tabBtnUsers = document.getElementById('tabBtnUsers');
  const tabBtnSettings = document.getElementById('tabBtnSettings');

  const sectionProducts = document.getElementById('sectionProducts');
  const sectionOrders = document.getElementById('sectionOrders');
  const sectionUsers = document.getElementById('sectionUsers');
  const sectionSettings = document.getElementById('sectionSettings');
  const addProductBtn = document.getElementById('addProductBtn');

  // Reset all buttons
  [tabBtnProducts, tabBtnOrders, tabBtnUsers, tabBtnSettings].forEach(btn => {
    if (btn) btn.className = 'px-4 sm:px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-white dark:bg-[#252B33] text-gray-700 dark:text-gray-200 hover:bg-[#F4F5F6] dark:hover:bg-[#414852] border border-gray-200 dark:border-gray-700 transition';
  });

  // Hide all sections
  [sectionProducts, sectionOrders, sectionUsers, sectionSettings].forEach(sec => {
    if (sec) sec.classList.add('hidden');
  });

  if (tab === 'products') {
    tabBtnProducts.className = 'px-4 sm:px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-[#252B33] text-white shadow-sm';
    sectionProducts.classList.remove('hidden');
    if (addProductBtn) addProductBtn.classList.remove('hidden');
  } else if (tab === 'orders') {
    tabBtnOrders.className = 'px-4 sm:px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-[#252B33] text-white shadow-sm';
    sectionOrders.classList.remove('hidden');
    if (addProductBtn) addProductBtn.classList.add('hidden');
  } else if (tab === 'users') {
    tabBtnUsers.className = 'px-4 sm:px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-[#252B33] text-white shadow-sm';
    sectionUsers.classList.remove('hidden');
    if (addProductBtn) addProductBtn.classList.add('hidden');
    loadUsers();
  } else if (tab === 'settings') {
    tabBtnSettings.className = 'px-4 sm:px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-[#252B33] text-white shadow-sm';
    sectionSettings.classList.remove('hidden');
    loadSettings();
  }
}

// Settings Load / Save
async function loadSettings() {
  try {
    const res = await fetch(`${API_BASE}/products/settings`, {
      cache: 'no-store',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('elegance_token')}`
      }
    });
    const data = await res.json();
    if (data.success && data.data) {
      fillSettingsForm(data.data);
    }
  } catch (err) {
    console.error('Error loading settings:', err);
  }
}

function fillSettingsForm(settings) {
  if (!settings) return;
  applyAdminBrandSettings(settings);

  const logoInput = document.getElementById('settingsLogoUrl');
  if (logoInput) logoInput.value = settings.logoUrl || '';
  setSettingsLogoPreview(settings.logoUrl || '');

  const nameInput = document.getElementById('settingsSiteName');
  if (nameInput) nameInput.value = settings.siteName || '';

  const taglineInput = document.getElementById('settingsSiteTagline');
  if (taglineInput) taglineInput.value = settings.siteTagline || '';
}

function setSettingsLogoPreview(source) {
  const preview = document.getElementById('logoPreview');
  const fallback = document.getElementById('logoPreviewFallback');
  const removeButton = document.getElementById('removeSettingsLogoBtn');
  if (!preview || !fallback) return;

  if (source) {
    preview.src = source;
    preview.classList.remove('hidden');
    fallback.classList.add('hidden');
    if (removeButton) removeButton.classList.remove('hidden');
  } else {
    preview.removeAttribute('src');
    preview.classList.add('hidden');
    fallback.classList.remove('hidden');
    if (removeButton) removeButton.classList.add('hidden');
  }
}

function handleLogoDragOver(event) {
  event.preventDefault();
  document.getElementById('settingsLogoDropzone')?.classList.add('is-dragging');
}

function handleLogoDragLeave(event) {
  event.preventDefault();
  const dropzone = document.getElementById('settingsLogoDropzone');
  if (dropzone && event.relatedTarget && dropzone.contains(event.relatedTarget)) return;
  dropzone?.classList.remove('is-dragging');
}

function handleLogoDrop(event) {
  event.preventDefault();
  document.getElementById('settingsLogoDropzone')?.classList.remove('is-dragging');
  const file = event.dataTransfer?.files?.[0];
  if (file) processSettingsLogo(file);
}

function previewSettingsLogo(input) {
  const file = input.files?.[0];
  if (file) processSettingsLogo(file);
  input.value = '';
}

function processSettingsLogo(file) {
  uploadSelectedImage(file, {
    onPreview: setSettingsLogoPreview,
    onError: () => setSettingsLogoPreview(document.getElementById('settingsLogoUrl').value),
    onSaved: url => {
      document.getElementById('settingsLogoUrl').value = url;
      setSettingsLogoPreview(url);
    }
  });
}

function compressImageFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('تعذر قراءة الصورة'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('اختر ملف صورة صالحاً'));
      image.onload = () => {
        const maxDimension = 900;
        const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        if (!context) return reject(new Error('تعذر تجهيز الصورة'));
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        let dataUrl = canvas.toDataURL('image/webp', 0.82);
        if (dataUrl.length > 1_300_000) dataUrl = canvas.toDataURL('image/webp', 0.65);
        if (dataUrl.length > 1_400_000) return reject(new Error('جرّب صورة أصغر حجماً أو أبعاداً'));
        resolve(dataUrl);
      };
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

async function uploadSelectedImage(file, { onPreview, onSaved, onError }) {
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
    Swal.fire('صيغة غير مدعومة', 'اختر صورة بصيغة PNG أو JPG أو WebP.', 'warning');
    return;
  }
  if (file.size > 8 * 1024 * 1024) {
    Swal.fire('الصورة كبيرة', 'يجب ألا يتجاوز حجم الصورة 8 MB.', 'warning');
    return;
  }

  pendingImageUploads++;
  try {
    const image = await compressImageFile(file);
    onPreview(image);
    const response = await fetch(`${API_BASE}/uploads`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ image })
    });
    const data = await response.json();
    if (!response.ok || !data.success || !data.data?.url) throw new Error(data.error || 'تعذر رفع الصورة');
    onSaved(data.data.url);
  } catch (err) {
    if (onError) onError();
    Swal.fire('تعذر رفع الصورة', err.message || 'حدث خطأ أثناء رفع الصورة إلى الخادم.', 'error');
  } finally {
    pendingImageUploads--;
  }
}

function removeSettingsLogo() {
  const input = document.getElementById('settingsLogoUrl');
  if (input) input.value = '';
  setSettingsLogoPreview('');
}

async function saveSettings() {
  if (pendingImageUploads > 0) {
    Swal.fire('انتظر قليلاً', 'يتم رفع الصورة إلى الخادم الآن.', 'info');
    return;
  }
  const logoUrl = document.getElementById('settingsLogoUrl')?.value.trim();
  const siteName = document.getElementById('settingsSiteName')?.value.trim();
  const siteTagline = document.getElementById('settingsSiteTagline')?.value.trim();

  const payload = { logoUrl, siteName, siteTagline };

  try {
    const res = await fetch(`${API_BASE}/products/settings`, {
      method: 'PATCH',
      cache: 'no-store',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('elegance_token')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.success) {
      applyAdminBrandSettings(data.data || payload);
      localStorage.setItem('elegance_site_settings', JSON.stringify(data.data || payload));
      Swal.fire('تم الحفظ!', 'تم حفظ إعدادات الموقع بنجاح.', 'success');
    } else {
      Swal.fire('خطأ', data.error || 'تعذر حفظ الإعدادات', 'error');
    }
  } catch (err) {
    console.error('Error saving settings:', err);
    Swal.fire('خطأ', 'حدث خطأ في الاتصال بالخادم', 'error');
  }
}

// Load Dashboard Metrics
async function loadStats() {
  try {
    const res = await fetch(`${API_BASE}/stats`, {
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!data.success) return;

    const stats = data.data;
    document.getElementById('statTotalSales').textContent = `${stats.totalSales.toLocaleString()} ر.س`;
    document.getElementById('statTotalOrders').textContent = stats.totalOrders;
    document.getElementById('statTotalProducts').textContent = stats.totalProducts;
    document.getElementById('statLowStock').textContent = stats.lowStockCount;
  } catch (err) {
    console.error('Error loading stats:', err);
  }
}

// Load Products
async function loadProducts() {
  try {
    const res = await fetch(`${API_BASE}/products`);
    const data = await res.json();
    if (!data.success) return;

    allProducts = data.data;
    renderProductsTable(allProducts);
  } catch (err) {
    console.error('Error loading products:', err);
  }
}

// Render Products Table
function renderProductsTable(products) {
  const tbody = document.getElementById('productsTableBody');
  if (!tbody) return;

  if (products.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-10 text-gray-400">لا توجد منتجات مطابقة</td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = products.map(p => `
    <tr class="border-b border-gray-100 dark:border-gray-800 hover:bg-[#F4F5F6]/60 dark:hover:bg-[#252B33] transition">
      <td class="py-3 px-4">
        <img src="${p.image}" alt="${p.name}" class="w-12 h-14 object-cover object-top rounded-lg bg-[#F4F5F6] dark:bg-[#252B33] border border-[#DDE1E5] dark:border-gray-700">
      </td>
      <td class="py-3 px-4">
        <div class="font-bold text-gray-900 dark:text-gray-100 text-sm">${p.name}</div>
        <div class="text-xs text-gray-400 dark:text-gray-400">${p.categoryName || p.category}</div>
      </td>
      <td class="py-3 px-4">
        <div class="font-bold text-[#252B33] dark:text-white text-sm">${p.price} ر.س</div>
        ${p.oldPrice ? `<div class="text-xs text-gray-400 line-through">${p.oldPrice} ر.س</div>` : ''}
      </td>
      <td class="py-3 px-4">
        <span class="px-2.5 py-1 rounded-full text-xs font-bold ${
          p.stock > 10 ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400' : (p.stock > 0 ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400' : 'bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-400')
        }">
          ${p.stock} قطعة
        </span>
      </td>
      <td class="py-3 px-4">
        <span class="text-xs px-2.5 py-1 rounded-full bg-[#F4F5F6] dark:bg-[#2D3139] text-[#252B33] dark:text-gray-200 font-semibold border border-[#DDE1E5] dark:border-gray-700">
          ${p.badge || 'لا يوجد'}
        </span>
      </td>
      <td class="py-3 px-4 text-xs text-amber-500 font-bold">
        ⭐ ${p.rating} (${p.reviewsCount})
      </td>
      <td class="py-3 px-4">
        <div class="flex items-center gap-2">
          <button onclick="openEditProductModal(${p.id})" class="p-2 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg transition" title="تعديل">
            <i class="ph ph-note-pencil text-lg"></i>
          </button>
          <button onclick="confirmDeleteProduct(${p.id}, '${p.name}')" class="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition" title="حذف">
            <i class="ph ph-trash text-lg"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

// Load Orders
async function loadOrders() {
  try {
    const res = await fetch(`${API_BASE}/orders`, {
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (!data.success) return;

    allOrders = data.data;
    renderOrdersTable(allOrders);
  } catch (err) {
    console.error('Error loading orders:', err);
  }
}

// Render Orders Table
function renderOrdersTable(orders) {
  const tbody = document.getElementById('ordersTableBody');
  if (!tbody) return;

  if (orders.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-10 text-gray-400">لا توجد طلبات واردة حتى الآن</td>
      </tr>
    `;
    return;
  }

  const statusColors = {
    'جديد': 'bg-blue-50 text-blue-700 border-blue-200',
    'قيد المعالجة': 'bg-amber-50 text-amber-700 border-amber-200',
    'تم الشحن': 'bg-purple-50 text-purple-700 border-purple-200',
    'تم التوصيل': 'bg-emerald-50 text-emerald-700 border-emerald-200',
    'ملغي': 'bg-red-50 text-red-700 border-red-200'
  };

  tbody.innerHTML = orders.map(o => `
    <tr class="border-b border-gray-100 dark:border-gray-800 hover:bg-[#F4F5F6]/60 dark:hover:bg-[#252B33] transition">
      <td class="py-3 px-4 font-mono font-bold text-xs text-gray-700 dark:text-gray-300">#${o.id}</td>
      <td class="py-3 px-4">
        <div class="font-bold text-gray-800 dark:text-gray-100 text-sm">${o.customer.name}</div>
        <div class="text-xs text-gray-400 font-mono">${o.customer.phone}</div>
      </td>
      <td class="py-3 px-4 text-xs text-gray-600 dark:text-gray-300">
        <div>${o.customer.city}</div>
        <div class="text-gray-400 text-[11px] truncate max-w-xs">${o.customer.address}</div>
      </td>
      <td class="py-3 px-4 text-xs font-semibold text-gray-700 dark:text-gray-300">
        ${o.items ? o.items.length : 0} منتجات
      </td>
      <td class="py-3 px-4 font-extrabold text-[#252B33] dark:text-white text-sm">
        ${o.total} ر.س
      </td>
      <td class="py-3 px-4 text-xs">
        <span class="px-2 py-0.5 rounded font-medium ${o.paymentMethod === 'cod' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400' : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'}">
          ${o.paymentMethod === 'cod' ? 'الدفع عند الاستلام' : 'بطاقة مدى / فيزا'}
        </span>
      </td>
      <td class="py-3 px-4">
        <select
          onchange="updateOrderStatus('${o.id}', this.value)"
          class="text-xs font-bold border rounded-lg px-2.5 py-1.5 focus:outline-none transition dark:bg-[#252B33] dark:border-gray-700 ${statusColors[o.status] || 'bg-gray-50 text-gray-700 border-gray-200'}"
        >
          <option value="جديد" ${o.status === 'جديد' ? 'selected' : ''}>جديد</option>
          <option value="قيد المعالجة" ${o.status === 'قيد المعالجة' ? 'selected' : ''}>قيد المعالجة</option>
          <option value="تم الشحن" ${o.status === 'تم الشحن' ? 'selected' : ''}>تم الشحن</option>
          <option value="تم التوصيل" ${o.status === 'تم التوصيل' ? 'selected' : ''}>تم التوصيل</option>
          <option value="ملغي" ${o.status === 'ملغي' ? 'selected' : ''}>ملغي</option>
        </select>
      </td>
    </tr>
  `).join('');
}

// Update Order Status via API
async function updateOrderStatus(orderId, newStatus) {
  try {
    const res = await fetch(`${API_BASE}/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status: newStatus })
    });
    const data = await res.json();
    if (data.success) {
      Swal.fire({
        toast: true,
        position: 'bottom-start',
        icon: 'success',
        title: `تم تحديث حالة الطلب #${orderId} إلى: ${newStatus}`,
        showConfirmButton: false,
        timer: 2500
      });
      loadOrders();
    } else {
      Swal.fire('خطأ', data.error || 'غير مصرح', 'error');
    }
  } catch (err) {
    console.error('Error updating order:', err);
  }
}

// ================= USERS & PERMISSIONS MANAGEMENT =================

// Load Users from API
async function loadUsers() {
  try {
    const res = await fetch(`${API_BASE}/auth/users`, {
      headers: getAuthHeaders()
    });
    const data = await res.json();
    if (data.success) {
      allUsers = data.data;
      renderUsersTable(allUsers);
    }
  } catch (err) {
    console.error('Error loading users:', err);
  }
}

// Render Users Table
function renderUsersTable(users) {
  const tbody = document.getElementById('usersTableBody');
  if (!tbody) return;

  if (users.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-10 text-gray-400">لا يوجد مستخدمون مسجلون حالياً</td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = users.map(u => {
    const isAdmin = u.role === 'admin';
    return `
      <tr class="border-b border-gray-100 dark:border-gray-800 hover:bg-[#F4F5F6]/60 dark:hover:bg-[#252B33] transition">
        <td class="py-3 px-4">
          <div class="flex items-center gap-3">
            <img src="${u.picture || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}" class="w-9 h-9 rounded-full object-cover border border-[#DDE1E5] dark:border-gray-700">
            <div>
              <div class="font-bold text-gray-900 dark:text-white text-xs">${u.name}</div>
              <div class="text-[10px] text-gray-400">ID: #${u.id}</div>
            </div>
          </div>
        </td>
        <td class="py-3 px-4 font-mono text-xs text-gray-700 dark:text-gray-300">
          ${u.email}
        </td>
        <td class="py-3 px-4 text-xs">
          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg ${u.provider === 'google' ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400' : 'bg-[#F4F5F6] dark:bg-[#2D3139] text-gray-700 dark:text-gray-300'} font-semibold text-[11px]">
            ${u.provider === 'google' ? '🌐 حساب Google' : '🔐 نظام داخلي'}
          </span>
        </td>
        <td class="py-3 px-4">
          <span class="px-3 py-1 rounded-full text-xs font-bold ${
            isAdmin ? 'bg-[#F4F5F6] dark:bg-[#252B33] text-[#252B33] border border-[#DDE1E5] dark:border-gray-800' : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
          }">
            ${isAdmin ? '👑 مديرة (Admin)' : '🛍️ عميلة (Customer)'}
          </span>
        </td>
        <td class="py-3 px-4 text-xs text-gray-500 dark:text-gray-400">
          ${isAdmin
            ? '<span class="text-emerald-600 dark:text-emerald-400 font-semibold">تحكم كامل (منتجات، طلبات، إحصائيات، مستخدمين)</span>'
            : '<span>تصفح، شراء، وتتبع الطلبات الخاصة</span>'
          }
        </td>
        <td class="py-3 px-4">
          <button
            onclick="toggleUserRole(${u.id}, '${u.role}')"
            class="px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              isAdmin
                ? 'bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/40 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-700'
                : 'bg-[#252B33] hover:bg-[#414852] text-white shadow-sm'
            }"
          >
            <i class="ph ${isAdmin ? 'ph-arrow-down' : 'ph-crown'} text-sm"></i>
            <span>${isAdmin ? 'تنزيل لعميلة' : 'ترقية لمديرة 👑'}</span>
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

// Toggle User Role (Admin <-> Customer)
async function toggleUserRole(userId, currentRole) {
  const newRole = currentRole === 'admin' ? 'customer' : 'admin';
  const roleTitle = newRole === 'admin' ? 'مسؤول (Admin)' : 'عميل (Customer)';

  Swal.fire({
    title: 'تغيير صلاحية المستخدم',
    text: `هل أنتِ متأكدة من تغيير رتبة هذا المستخدم إلى: ${roleTitle}؟`,
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#252B33',
    cancelButtonColor: '#6b7280',
    confirmButtonText: 'نعم، تغيير الرتبة',
    cancelButtonText: 'إلغاء'
  }).then(async (result) => {
    if (result.isConfirmed) {
      try {
        const res = await fetch(`${API_BASE}/auth/users/${userId}/role`, {
          method: 'PATCH',
          headers: getAuthHeaders(),
          body: JSON.stringify({ role: newRole })
        });
        const data = await res.json();
        if (data.success) {
          Swal.fire('تم بنجاح!', data.message, 'success');
          loadUsers();
        } else {
          Swal.fire('خطأ', data.error || 'تعذر تغيير الصلاحية', 'error');
        }
      } catch (err) {
        console.error('Error toggling role:', err);
      }
    }
  });
}

// Open Add Product Modal
function openAddProductModal() {
  document.getElementById('productModalTitle').textContent = 'إضافة منتج نسائي جديد';
  document.getElementById('productId').value = '';
  document.getElementById('productForm').reset();
  document.getElementById('prodImage').value = '';
  setProductImagePreview('');
  document.getElementById('productModal').classList.remove('hidden');
}

// Open Edit Product Modal
function openEditProductModal(id) {
  const product = allProducts.find(p => p.id === id);
  if (!product) return;

  document.getElementById('productModalTitle').textContent = 'تعديل بيانات المنتج';
  document.getElementById('productId').value = product.id;
  document.getElementById('prodName').value = product.name;
  document.getElementById('prodNameEn').value = product.nameEn || '';
  document.getElementById('prodCategory').value = product.category;
  document.getElementById('prodPrice').value = product.price;
  document.getElementById('prodOldPrice').value = product.oldPrice || '';
  document.getElementById('prodStock').value = product.stock;
  document.getElementById('prodBadge').value = product.badge || '';
  document.getElementById('prodImage').value = product.image;
  setProductImagePreview(product.image);
  document.getElementById('prodSizes').value = Array.isArray(product.sizes) ? product.sizes.join(', ') : (product.sizes || '');
  document.getElementById('prodColors').value = Array.isArray(product.colors) ? product.colors.join(', ') : (product.colors || '');
  document.getElementById('prodDescription').value = product.description;

  document.getElementById('productModal').classList.remove('hidden');
}

function closeProductModal() {
  document.getElementById('productModal').classList.add('hidden');
}

function previewProductImage(input) {
  const file = input.files?.[0];
  if (!file) return;
  input.value = '';
  document.getElementById('prodImageError').classList.add('hidden');
  uploadSelectedImage(file, {
    onPreview: setProductImagePreview,
    onError: () => setProductImagePreview(document.getElementById('prodImage').value),
    onSaved: url => {
      document.getElementById('prodImage').value = url;
      setProductImagePreview(url);
    }
  });
}

function setProductImagePreview(source) {
  const previewImg = document.getElementById('prodImageImg');
  const previewPlaceholder = document.getElementById('prodImagePlaceholder');
  if (!previewImg || !previewPlaceholder) return;
  if (source) {
    previewImg.src = source;
    previewImg.classList.remove('hidden');
    previewPlaceholder.classList.add('hidden');
  } else {
    previewImg.removeAttribute('src');
    previewImg.classList.add('hidden');
    previewPlaceholder.classList.remove('hidden');
  }
}

// Save Product (Create or Update)
async function handleSaveProduct(e) {
  e.preventDefault();
  if (pendingImageUploads > 0) {
    Swal.fire('انتظر قليلاً', 'يتم رفع الصورة إلى الخادم الآن.', 'info');
    return;
  }

  const id = document.getElementById('productId').value;
  const isEditing = Boolean(id);

  const payload = {
    name: document.getElementById('prodName').value.trim(),
    nameEn: document.getElementById('prodNameEn').value.trim(),
    category: document.getElementById('prodCategory').value,
    price: Number(document.getElementById('prodPrice').value),
    oldPrice: document.getElementById('prodOldPrice').value ? Number(document.getElementById('prodOldPrice').value) : null,
    stock: Number(document.getElementById('prodStock').value),
    badge: document.getElementById('prodBadge').value.trim(),
    image: document.getElementById('prodImage').value.trim(),
    sizes: document.getElementById('prodSizes').value,
    colors: document.getElementById('prodColors').value,
    description: document.getElementById('prodDescription').value.trim()
  };

  try {
    const url = isEditing ? `${API_BASE}/products/${id}` : `${API_BASE}/products`;
    const method = isEditing ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method: method,
      headers: getAuthHeaders(),
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (data.success) {
      closeProductModal();
      Swal.fire({
        icon: 'success',
        title: isEditing ? 'تم تحديث المنتج بنجاح!' : 'تمت إضافة المنتج بنجاح!',
        showConfirmButton: false,
        timer: 2000
      });
      loadProducts();
      loadStats();
    } else {
      Swal.fire('خطأ', data.error || 'تعذر حفظ المنتج', 'error');
    }
  } catch (err) {
    console.error('Error saving product:', err);
    Swal.fire('خطأ', 'حدث خطأ في الاتصال بالخادم', 'error');
  }
}

// Confirm Delete Product
function confirmDeleteProduct(id, name) {
  Swal.fire({
    title: 'هل أنتِ متأكدة؟',
    text: `سيتم حذف منتج "${name}" نهائياً من المتجر!`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#e11d48',
    cancelButtonColor: '#6b7280',
    confirmButtonText: 'نعم، احذف',
    cancelButtonText: 'إلغاء'
  }).then(async (result) => {
    if (result.isConfirmed) {
      try {
        const res = await fetch(`${API_BASE}/products/${id}`, {
          method: 'DELETE',
          headers: getAuthHeaders()
        });
        const data = await res.json();
        if (data.success) {
          Swal.fire('تم الحذف!', 'تم حذف المنتج بنجاح.', 'success');
          loadProducts();
          loadStats();
        } else {
          Swal.fire('خطأ', data.error || 'غير مصرح بحذف المنتج', 'error');
        }
      } catch (err) {
        console.error('Error deleting product:', err);
      }
    }
  });
}
